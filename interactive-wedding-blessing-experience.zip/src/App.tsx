import { useCallback, useEffect, useRef, useState, type ComponentType } from "react";
import { sound } from "./audio";
import { GlobalDefs, LITE } from "./art";
import type { SceneProps } from "./ui";
import Invitation from "./scenes/Invitation";
import Sunrise from "./scenes/Sunrise";
import Blooming from "./scenes/Blooming";
import BridgeScene from "./scenes/BridgeScene";
import Lanterns from "./scenes/Lanterns";
import Game from "./scenes/Game";
import Reveal from "./scenes/Reveal";
import Letter from "./scenes/Letter";

const SCENES: ComponentType<SceneProps>[] = [Invitation, Sunrise, Blooming, BridgeScene, Lanterns, Game, Reveal, Letter];

// how each scene arrives, and how the previous one leaves while it does
const ENTER = ["dissolve", "light", "push", "iris", "push", "iris", "slow", "dissolve"] as const;
const EXIT: Record<(typeof ENTER)[number], string> = { dissolve: "slow", light: "fade", push: "push", iris: "hold", slow: "slow" };
const NEXT_LABEL: Record<number, string> = { 1: "Continue", 2: "Continue", 3: "Walk on", 4: "Let’s play", 5: "Continue", 6: "One last thing" };

type Inst = { id: number; i: number };
type Ripple = { id: number; x: number; y: number };

export default function App() {
  const [inst, setInst] = useState<Inst[]>([{ id: 0, i: 0 }]);
  const [ready, setReady] = useState(false);
  const [on, setOn] = useState(false);
  const [soundHint, setSoundHint] = useState(true);
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const idRef = useRef(0);
  const lock = useRef(false);
  const cleanup = useRef<number | undefined>(undefined);
  const rid = useRef(0);

  const cur = inst[inst.length - 1];
  const curRef = useRef(cur);
  curRef.current = cur;

  useEffect(() => {
    if (LITE) document.documentElement.classList.add("lite");
    const id = window.setTimeout(() => setSoundHint(false), 12000);
    return () => clearTimeout(id);
  }, []);

  const go = useCallback((to: number) => {
    if (lock.current) return;
    lock.current = true;
    window.setTimeout(() => (lock.current = false), 900);
    idRef.current += 1;
    const n = { id: idRef.current, i: to };
    setInst((l) => [l[l.length - 1], n]);
    setReady(false);
    clearTimeout(cleanup.current);
    cleanup.current = window.setTimeout(() => setInst((l) => l.slice(-1)), 1900);
  }, []);

  const next = useCallback(() => {
    sound.sfx("pop");
    go(Math.min(curRef.current.i + 1, SCENES.length - 1));
  }, [go]);
  const replay = useCallback(() => {
    sound.sfx("chime");
    lock.current = false;
    go(0);
  }, [go]);

  const toggleSound = async () => {
    setSoundHint(false);
    const s = await sound.toggle();
    setOn(s);
  };

  const onDown = (e: React.PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const id = ++rid.current;
    setRipples((l) => [...l.slice(-3), { id, x: e.clientX - r.left, y: e.clientY - r.top }]);
    window.setTimeout(() => setRipples((l) => l.filter((q) => q.id !== id)), 800);
  };

  const showNext = ready && cur.i >= 1 && cur.i <= 6;

  return (
    <div className="shell">
      <GlobalDefs />
      <div className="stage grain" onPointerDown={onDown}>
        {inst.map((s) => {
          const Scene = SCENES[s.i];
          const isCur = s.id === cur.id;
          const e = ENTER[cur.i];
          const hasPrev = inst.length > 1;
          const cls = isCur ? (hasPrev || s.id > 0 ? `enter enter-${e}` : "") : `exit exit-${EXIT[e]}`;
          return (
            <div key={s.id} className={`scene-layer ${cls}`} style={{ zIndex: isCur ? 2 : 1, pointerEvents: isCur ? "auto" : "none" }}>
              <Scene
                active={isCur}
                ready={() => {
                  if (curRef.current.id === s.id) setReady(true);
                }}
                next={next}
                replay={replay}
              />
            </div>
          );
        })}

        <div className="dots" aria-hidden="true">
          {SCENES.map((_, i) => (
            <i key={i} className={i === cur.i ? "on" : i < cur.i ? "past" : ""} />
          ))}
        </div>

        <div className="snd-wrap">
          {soundHint && !on && <span className="snd-hint">Tap for gentle music</span>}
          <button className="snd" onClick={toggleSound} aria-label={on ? "Turn sound off" : "Turn sound on"} aria-pressed={on}>
            <svg viewBox="0 0 24 24" width="100%" height="100%" aria-hidden="true">
              <path d="M4 9v6h4l5 4V5L8 9H4Z" fill="currentColor" />
              {on ? (
                <path d="M16 8.5a5 5 0 0 1 0 7M18.5 6a8.5 8.5 0 0 1 0 12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" fill="none" />
              ) : (
                <path d="M16.5 9.5l5 5m0-5l-5 5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" fill="none" />
              )}
            </svg>
          </button>
        </div>

        {showNext && (
          <button key={`c${cur.id}`} className="cont" onClick={next}>
            <span>{NEXT_LABEL[cur.i]}</span>
            <svg viewBox="0 0 24 24" width="1.1em" height="1.1em" aria-hidden="true">
              <path d="M5 12h13M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            </svg>
          </button>
        )}

        {ripples.map((r) => (
          <i key={r.id} className="ripple" style={{ left: r.x, top: r.y }} />
        ))}
      </div>
    </div>
  );
}
