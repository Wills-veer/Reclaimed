// Gentle generative ambience + tiny sound effects. Muted by default, never autoplays.
type SfxName = "open" | "bloom" | "chime" | "light" | "award" | "pop" | "water";

const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

const CHORDS = [
  [48, 52, 55, 59],
  [45, 52, 55, 60],
  [53, 57, 60, 64],
  [43, 55, 59, 62],
];
const MELODY = [72, 74, 76, 79, 81, 84, 86];

class SoundEngine {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private bus!: GainNode;
  private timers: number[] = [];
  private chordIdx = 0;
  on = false;

  private init() {
    if (this.ctx) return;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = 0;
    this.bus = ctx.createGain();
    const dly = ctx.createDelay(1);
    dly.delayTime.value = 0.34;
    const fb = ctx.createGain();
    fb.gain.value = 0.38;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 2200;
    this.bus.connect(this.master);
    this.bus.connect(dly);
    dly.connect(lp);
    lp.connect(fb);
    fb.connect(dly);
    lp.connect(this.master);
    this.master.connect(ctx.destination);
    document.addEventListener("visibilitychange", () => {
      if (!this.ctx) return;
      if (document.hidden) this.ctx.suspend();
      else if (this.on) this.ctx.resume();
    });
  }

  private tone(freq: number, t0: number, dur: number, vol: number, type: OscillatorType = "sine", attack = 0.02) {
    if (!this.ctx) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(vol, t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(this.bus);
    o.start(t0);
    o.stop(t0 + dur + 0.05);
  }

  private pad() {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime;
    const chord = CHORDS[this.chordIdx++ % CHORDS.length];
    chord.forEach((m, i) => this.tone(mtof(m), t + i * 0.12, 9, 0.035, "sine", 2.4));
  }

  private note() {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime;
    const m = MELODY[Math.floor(Math.random() * MELODY.length)];
    this.tone(mtof(m), t, 2.4, 0.05, "triangle", 0.01);
    this.tone(mtof(m + 12), t, 1.2, 0.012, "sine", 0.01);
    this.timers.push(window.setTimeout(() => this.note(), 1100 + Math.random() * 1500));
  }

  async enable() {
    this.init();
    if (!this.ctx) return false;
    await this.ctx.resume();
    this.on = true;
    const t = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(t);
    this.master.gain.setValueAtTime(this.master.gain.value, t);
    this.master.gain.linearRampToValueAtTime(0.8, t + 1.2);
    this.pad();
    this.timers.push(window.setInterval(() => this.pad(), 8000));
    this.timers.push(window.setTimeout(() => this.note(), 600));
    this.sfx("chime");
    return true;
  }

  disable() {
    this.on = false;
    this.timers.forEach((id) => {
      clearTimeout(id);
      clearInterval(id);
    });
    this.timers = [];
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(t);
    this.master.gain.setValueAtTime(this.master.gain.value, t);
    this.master.gain.linearRampToValueAtTime(0, t + 0.5);
    const c = this.ctx;
    window.setTimeout(() => {
      if (!this.on) c.suspend();
    }, 800);
  }

  async toggle() {
    if (this.on) {
      this.disable();
      return false;
    }
    return this.enable();
  }

  sfx(name: SfxName) {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime;
    switch (name) {
      case "open": {
        const len = Math.floor(this.ctx.sampleRate * 0.5);
        const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
        const d = buf.getChannelData(0);
        for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
        const src = this.ctx.createBufferSource();
        src.buffer = buf;
        const bp = this.ctx.createBiquadFilter();
        bp.type = "bandpass";
        bp.frequency.value = 2200;
        const g = this.ctx.createGain();
        g.gain.value = 0.16;
        src.connect(bp);
        bp.connect(g);
        g.connect(this.bus);
        src.start(t);
        [76, 81, 88].forEach((m, i) => this.tone(mtof(m), t + 0.15 + i * 0.14, 1.6, 0.05, "triangle"));
        break;
      }
      case "bloom":
        this.tone(mtof(79), t, 0.7, 0.06, "sine");
        this.tone(mtof(86), t + 0.09, 0.9, 0.05, "sine");
        break;
      case "chime":
        [72, 76, 79, 84].forEach((m, i) => this.tone(mtof(m), t + i * 0.11, 1.6, 0.05, "triangle"));
        break;
      case "light":
        this.tone(mtof(91), t, 1.1, 0.03, "sine");
        break;
      case "pop":
        this.tone(mtof(84), t, 0.25, 0.05, "triangle");
        break;
      case "water":
        this.tone(mtof(96), t, 0.15, 0.03, "sine");
        this.tone(mtof(91), t + 0.07, 0.15, 0.025, "sine");
        break;
      case "award":
        [72, 76, 79, 84, 88, 91].forEach((m, i) => this.tone(mtof(m), t + i * 0.12, 2.2, 0.06, "triangle"));
        break;
    }
  }
}

export const sound = new SoundEngine();
