import { useEffect, useRef, type CSSProperties, type ReactNode } from "react";
import { LITE, P, rng } from "./art";

export type SceneProps = {
  active: boolean;
  ready: () => void;
  next: () => void;
  replay: () => void;
};

const reduced = () => typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
const sty = (o: Record<string, string | number>) => o as CSSProperties;

/* ───── parallax: pointer / tilt + a slow idle drift, written to CSS variables only ───── */
export function useParallax(ref: React.RefObject<HTMLDivElement | null>, enabled = true) {
  useEffect(() => {
    const el = ref.current;
    if (!el || !enabled || LITE || reduced()) return;
    let tx = 0;
    let ty = 0;
    let cx = 0;
    let cy = 0;
    let raf = 0;
    let last = 0;
    const clamp = (v: number) => Math.max(-1, Math.min(1, v));
    const onMove = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      tx = clamp(((e.clientX - r.left) / r.width - 0.5) * 2);
      ty = clamp(((e.clientY - r.top) / r.height - 0.5) * 2);
    };
    const onTilt = (e: DeviceOrientationEvent) => {
      if (e.gamma == null) return;
      tx = clamp(e.gamma / 25);
      ty = clamp(((e.beta ?? 45) - 45) / 25);
    };
    const loop = (t: number) => {
      raf = requestAnimationFrame(loop);
      if (t - last < 32) return;
      last = t;
      const ix = Math.sin(t / 3600) * 0.55;
      const iy = Math.cos(t / 5100) * 0.28;
      cx += (tx + ix - cx) * 0.07;
      cy += (ty + iy - cy) * 0.07;
      el.style.setProperty("--px", cx.toFixed(3));
      el.style.setProperty("--py", cy.toFixed(3));
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    const DOE = window.DeviceOrientationEvent as unknown as { requestPermission?: unknown } | undefined;
    if (DOE && typeof DOE.requestPermission !== "function") window.addEventListener("deviceorientation", onTilt, { passive: true });
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("deviceorientation", onTilt);
    };
  }, [ref, enabled]);
}

export function SceneRoot({ children, className = "", style }: { children: ReactNode; className?: string; style?: CSSProperties }) {
  const ref = useRef<HTMLDivElement>(null);
  useParallax(ref);
  return (
    <div ref={ref} className={`scene-root ${className}`} style={style}>
      {children}
    </div>
  );
}

/* ───── a depth layer: parallax wrapper + slow camera push ───── */
export function Layer({ depth = 0, z = 1.04, tx = 0, ty = 0, pd = 16, shadow = false, children, className = "", origin }: { depth?: number; z?: number; tx?: number; ty?: number; pd?: number; shadow?: boolean; children: ReactNode; className?: string; origin?: string }) {
  return (
    <div className={`layer ${shadow && !LITE ? "shadow" : ""} ${className}`} style={sty({ "--d": depth })}>
      <div className="push" style={sty({ "--z": z, "--tx": `${tx}px`, "--ty": `${ty}px`, "--pd": `${pd}s`, ...(origin ? { transformOrigin: origin } : {}) })}>
        {children}
      </div>
    </div>
  );
}

/* ───── typography reveals ───── */
export function Words({ children, delay = 0, step = 0.07, v = "rise", className = "" }: { children: string; delay?: number; step?: number; v?: "rise" | "blur" | "mask" | "glow" | "pop"; className?: string }) {
  const words = children.split(" ");
  return (
    <span className={className} aria-label={children}>
      {words.map((w, i) => (
        <span key={i}>
          <span aria-hidden="true" className={`wd wd-${v}`} style={{ animationDelay: `${delay + i * step}s` }}>
            {w}
          </span>
          {i < words.length - 1 ? " " : ""}
        </span>
      ))}
    </span>
  );
}

export function Fade({ children, delay = 0, className = "", as: Tag = "div", v = "up" }: { children: ReactNode; delay?: number; className?: string; as?: "div" | "p" | "span"; v?: "up" | "mask" | "plain" }) {
  return (
    <Tag className={`${v === "mask" ? "mask-in" : v === "plain" ? "fade-in-html" : "fade-up"} ${className}`} style={{ animationDelay: `${delay}s` }}>
      {children}
    </Tag>
  );
}

export function TextPanel({ pos, tone = "dark", scrim, children, className = "" }: { pos: "top" | "bottom"; tone?: "dark" | "light"; scrim: string; children: ReactNode; className?: string }) {
  return (
    <div className={`tp tp-${pos} tp-${tone} ${className}`} style={sty({ "--scrim": scrim })}>
      <div className="tp-in">{children}</div>
    </div>
  );
}

/* ───── drifting petals (html overlay) ───── */
export function Petals({ count = 12, cols = [P.blush, P.ivory, P.peach], delay = 0, seed = 1, size = 2.4 }: { count?: number; cols?: string[]; delay?: number; seed?: number; size?: number }) {
  const r = rng(seed);
  const n = LITE ? Math.ceil(count / 2) : count;
  return (
    <div className="petals" aria-hidden="true">
      {Array.from({ length: n }, (_, i) => {
        const t = 11 + r() * 9;
        return (
          <i
            key={i}
            className="petal"
            style={sty({
              left: `${(r() * 100).toFixed(1)}%`,
              "--s": `calc(var(--u) * ${(size * (0.7 + r() * 0.8)).toFixed(2)})`,
              "--t": `${t.toFixed(1)}s`,
              "--pdl": `${(delay + r() * t).toFixed(1)}s`,
              "--x1": `calc(var(--u) * ${((r() - 0.5) * 34).toFixed(1)})`,
              "--x2": `calc(var(--u) * ${((r() - 0.5) * 50).toFixed(1)})`,
              background: `linear-gradient(135deg, ${cols[i % cols.length]}, ${cols[(i + 1) % cols.length]})`,
            })}
          />
        );
      })}
    </div>
  );
}

export function Motes({ count = 18, seed = 4 }: { count?: number; seed?: number }) {
  const r = rng(seed);
  const n = LITE ? Math.ceil(count / 2) : count;
  return (
    <div className="petals" aria-hidden="true">
      {Array.from({ length: n }, (_, i) => (
        <i
          key={i}
          className="mote"
          style={sty({
            left: `${(r() * 100).toFixed(1)}%`,
            top: `${(20 + r() * 70).toFixed(1)}%`,
            "--s": `calc(var(--u) * ${(0.6 + r() * 1.2).toFixed(2)})`,
            "--t": `${(8 + r() * 8).toFixed(1)}s`,
            "--pdl": `${(-r() * 10).toFixed(1)}s`,
            "--x1": `calc(var(--u) * ${((r() - 0.5) * 12).toFixed(1)})`,
          })}
        />
      ))}
    </div>
  );
}

export function Heart({ size = 1, color = "#D98690", className = "" }: { size?: number; color?: string; className?: string }) {
  return (
    <svg viewBox="0 0 24 22" width={`${size}em`} height={`${size * 0.92}em`} className={className} style={{ display: "inline-block", verticalAlign: "-0.1em" }} aria-label="heart" role="img">
      <path d="M12 21C5 15.5 1.5 12 1.5 7.6 1.5 4.4 4 2 7 2c2.1 0 3.9 1.1 5 2.9C13.1 3.1 14.9 2 17 2c3 0 5.5 2.4 5.5 5.6C22.5 12 19 15.5 12 21Z" fill={color} />
    </svg>
  );
}

/* ───── touch guide ───── */
export function TapHint({ style, label }: { style?: CSSProperties; label?: string }) {
  return (
    <div className="hint" style={style} aria-hidden="true">
      <span className="hint-ring" />
      <span className="hint-ring r2" />
      <span className="hint-dot" />
      {label && <span className="hint-label">{label}</span>}
    </div>
  );
}

export function useReadyAfter(ready: () => void, ms: number) {
  const fn = useRef(ready);
  fn.current = ready;
  useEffect(() => {
    const id = window.setTimeout(() => fn.current(), ms);
    return () => clearTimeout(id);
  }, [ms]);
}
