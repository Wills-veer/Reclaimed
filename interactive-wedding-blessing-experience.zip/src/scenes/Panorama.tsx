import type { CSSProperties, ReactNode } from "react";
import { Arch, Bird, Bridge, Butterfly, Cloud, Fireflies, Flower, FLOWER_SETS, Grass, Hill, Lantern, LITE, P, Pole, RoundTree, Stream, Sun, Svg, Tree, Walkway, type Pt, type Rp } from "../art";
import { Layer } from "../ui";

const FAR: Pt[] = [[-20, 310], [60, 296], [140, 308], [196, 316], [260, 302], [340, 310], [420, 294]];
const MID: Pt[] = [[-20, 350], [80, 328], [170, 342], [250, 330], [340, 338], [420, 326]];
const NEAR: Pt[] = [[-20, 400], [90, 370], [200, 386], [300, 366], [420, 386]];
const GROUND: Pt[] = [[-20, 470], [100, 442], [220, 456], [420, 438]];
const GROUND2: Pt[] = [[-20, 566], [110, 544], [240, 556], [420, 538]];

const STREAM: Rp[] = [
  [252, 355, 6],
  [250, 400, 22],
  [240, 450, 46],
  [220, 505, 80],
  [190, 570, 120],
  [150, 650, 150],
  [110, 740, 190],
  [70, 830, 230],
];
const PATH_A: Rp[] = [
  [310, 830, 160],
  [302, 750, 120],
  [294, 670, 90],
  [290, 590, 64],
  [288, 540, 44],
  [286, 528, 40],
];
const PATH_B: Rp[] = [
  [136, 528, 40],
  [110, 490, 36],
  [104, 450, 30],
  [136, 410, 24],
  [172, 372, 16],
  [194, 344, 9],
  [196, 332, 6],
];

const FLOWERS: [number, number, number][] = [
  [60, 540, 0.5], [30, 580, 0.6], [88, 572, 0.55], [150, 490, 0.4], [164, 512, 0.38], [70, 432, 0.3], [92, 402, 0.28], [150, 432, 0.3],
  [360, 520, 0.5], [310, 560, 0.5], [374, 604, 0.6], [350, 664, 0.7], [380, 734, 0.85], [392, 424, 0.3], [40, 654, 0.7], [16, 724, 0.85],
  [152, 392, 0.22], [214, 372, 0.2], [120, 380, 0.22], [236, 392, 0.2],
];

const POSTS: [number, number, number][] = [
  [258, 596, 0.62], [326, 596, 0.62], [132, 506, 0.46], [88, 490, 0.42], [126, 450, 0.36], [82, 452, 0.36],
  [152, 410, 0.3], [118, 414, 0.3], [186, 376, 0.26], [158, 376, 0.26],
];

const rv = (name: "l" | "r" | "up" | "fade", at: number) => ({ cls: `rv rv-${name}`, st: { "--rd": `${at}s` } as CSSProperties });

function R({ n, at, children }: { n: "l" | "r" | "up" | "fade"; at: number; children: ReactNode }) {
  const { cls, st } = rv(n, at);
  return (
    <g className={cls} style={st}>
      {children}
    </g>
  );
}

export function Panorama({ still = false }: { still?: boolean }) {
  return (
    <div className={`pano ${still ? "still" : ""}`}>
      <div className={still ? "cam-still" : "cam"}>
        <Layer depth={0} z={1}>
          <Svg>
            <defs>
              <linearGradient id="pnsky" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#E3D5EA" />
                <stop offset=".2" stopColor="#F3D9DB" />
                <stop offset=".34" stopColor="#FAD0AE" />
                <stop offset=".46" stopColor="#FFE6C0" />
              </linearGradient>
            </defs>
            <rect width="400" height="800" fill="url(#pnsky)" />
            <circle cx="196" cy="300" r="250" fill="url(#g-sun)" className="glow-breathe" />
          </Svg>
        </Layer>

        <Layer depth={3} z={1}>
          <Svg>
            <g className="sunrise" style={{ animationDuration: "3.5s" }}>
              <Sun x={196} y={250} r={34} />
            </g>
          </Svg>
        </Layer>

        <Layer depth={6} z={1}>
          <Svg>
            <Cloud x={14} y={150} s={0.85} fill="#FFF3E4" op={0.8} dur={50} />
            <Cloud x={250} y={196} s={0.65} fill="#FFF3E4" op={0.75} dur={40} />
            <Bird x={90} y={100} s={0.9} />
            <Bird x={116} y={114} s={0.6} delay={0.4} />
            <Bird x={310} y={120} s={0.7} delay={0.8} />
          </Svg>
        </Layer>

        <Layer depth={9} z={1} shadow>
          <Svg>
            <R n="fade" at={0}>
              <Hill pts={FAR} fill="#CDBFE0" edge="#DDD2EA" />
            </R>
          </Svg>
        </Layer>

        <Layer depth={12} z={1} shadow>
          <Svg>
            <R n="r" at={1.1}>
              <Hill pts={MID} fill="#BBCEB2" edge="#CFDDC6" />
              <RoundTree x={30} y={346} s={0.4} fill={P.sageMid} fill2={P.sage} />
              <RoundTree x={62} y={336} s={0.3} fill={P.sageDeep} fill2={P.sageMid} />
              <RoundTree x={376} y={332} s={0.36} fill={P.sageMid} fill2={P.sage} />
            </R>
          </Svg>
        </Layer>

        <Layer depth={16} z={1} shadow>
          <Svg>
            <R n="l" at={1.6}>
              <Hill pts={NEAR} fill="#A4BE9C" edge="#B8CFB0" />
              <Hill pts={GROUND} fill="#98B891" edge="#ADCBA6" />
              <Hill pts={GROUND2} fill="#86A583" edge="#9BB798" />
            </R>
          </Svg>
        </Layer>

        <Layer depth={18} z={1}>
          <Svg>
            <Stream pts={STREAM} lines={6} delay={3.2} />
          </Svg>
        </Layer>

        <Layer depth={20} z={1}>
          <Svg>
            <Walkway pts={PATH_B} delay={3.8} glowColor="#FFE0A0" />
            <Walkway pts={PATH_A} delay={4.0} glowColor="#FFE0A0" />
          </Svg>
        </Layer>

        <Layer depth={22} z={1}>
          <Svg>
            <Tree x={336} y={452} s={0.55} delay={2.0} cols={[P.rose, P.blush, P.lav]} many={LITE ? 22 : 30} />
            <Tree x={44} y={458} s={0.36} delay={2.6} cols={[P.lavDeep, P.lav, P.blush]} seed={13} many={18} />
          </Svg>
        </Layer>

        <Layer depth={24} z={1}>
          <Svg>
            <Bridge x={211} y={528} w={150} h={26} thick={9} posts={6} delay={4.4} />
          </Svg>
        </Layer>

        <Layer depth={26} z={1}>
          <Svg>
            {FLOWERS.map(([x, y, s], i) => (
              <Flower key={i} x={x} y={y} s={s} h={40 + (i % 3) * 8} lean={((i % 5) - 2) * 3} d={3.4 + (i / FLOWERS.length) * 3} {...FLOWER_SETS[i % 6]} />
            ))}
          </Svg>
        </Layer>

        <Layer depth={28} z={1}>
          <Svg>
            {POSTS.map(([x, y, s], i) => (
              <g key={i}>
                <Pole x={x} y={y + 22 * s} h={46 * s} w={4 * s + 1} />
                <Lantern x={x} y={y} s={s} delay={6 + i * 0.32} />
              </g>
            ))}
          </Svg>
        </Layer>

        <Layer depth={30} z={1}>
          <Svg>
            <Arch x={196} y={332} s={0.55} delay={7.6} />
          </Svg>
        </Layer>

        <Layer depth={34} z={1}>
          <Svg>
            <Fireflies n={10} seed={11} area={[20, 300, 380, 520]} />
            <Butterfly x={100} y={470} s={0.9} c1={P.blush} c2={P.rose} v={1} />
            <Butterfly x={300} y={380} s={0.8} c1={P.lav} c2={P.ivory} v={2} />
          </Svg>
        </Layer>

        <Layer depth={40} z={1}>
          <Svg>
            <Grass x={10} y={816} s={1.5} n={11} h={70} seed={2} />
            <Grass x={392} y={816} s={1.5} n={11} h={74} seed={9} />
          </Svg>
        </Layer>
      </div>
    </div>
  );
}
