import { Butterfly, Cloud, Flower, FLOWER_SETS, Grass, Hill, P, Svg, Tree, type Pt } from "../art";
import { Fade, Layer, Petals, SceneRoot, TextPanel, Words, useReadyAfter, type SceneProps } from "../ui";

const FAR: Pt[] = [[-20, 340], [70, 306], [150, 324], [250, 298], [340, 318], [420, 302]];
const MID: Pt[] = [[-20, 392], [100, 356], [210, 380], [320, 350], [420, 374]];
const GROUND: Pt[] = [[-20, 436], [110, 414], [250, 430], [420, 410]];
const LOWER: Pt[] = [[-20, 482], [140, 462], [300, 478], [420, 460]];

// back / mid / front garden rows: [x, y, scale]
const BACK: [number, number, number][] = [[40, 408, 0.32], [90, 418, 0.34], [150, 420, 0.3], [250, 418, 0.3], [310, 414, 0.34], [364, 406, 0.32]];
const MIDROW: [number, number, number][] = [[24, 446, 0.5], [74, 452, 0.55], [128, 456, 0.5], [272, 454, 0.5], [326, 450, 0.55], [376, 444, 0.5]];
const FRONT: [number, number, number][] = [[14, 492, 0.8], [62, 500, 0.85], [112, 496, 0.7], [288, 498, 0.7], [338, 502, 0.85], [386, 494, 0.8], [168, 504, 0.55], [234, 506, 0.55]];

function Row({ list, d0, step, off = 0 }: { list: [number, number, number][]; d0: number; step: number; off?: number }) {
  return (
    <>
      {list.map(([x, y, s], i) => (
        <Flower key={i} x={x} y={y} s={s} h={44 + (i % 3) * 8} lean={((i % 5) - 2) * 3} d={d0 + i * step} {...FLOWER_SETS[(i + off) % FLOWER_SETS.length]} />
      ))}
    </>
  );
}

export default function Blooming({ ready }: SceneProps) {
  useReadyAfter(ready, 3000);
  return (
    <SceneRoot className="s3">
      <Layer depth={0} z={1.02} pd={22}>
        <Svg>
          <defs>
            <linearGradient id="s3sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#BCD6EA" />
              <stop offset=".3" stopColor="#D9E7EE" />
              <stop offset=".5" stopColor="#F5EEDF" />
            </linearGradient>
          </defs>
          <rect width="400" height="800" fill="url(#s3sky)" />
          <circle cx="330" cy="120" r="110" fill="url(#g-white)" opacity=".7" />
        </Svg>
      </Layer>

      <Layer depth={6} z={1.03} pd={22}>
        <Svg><g transform="translate(0 -48)">
          <Cloud x={14} y={90} s={0.9} op={0.92} dur={52} />
          <Cloud x={262} y={200} s={0.65} op={0.85} dur={40} />
          <Cloud x={120} y={286} s={0.5} op={0.8} dur={46} />
        </g></Svg>
      </Layer>

      <Layer depth={9} z={1.04} shadow>
        <Svg><g transform="translate(0 -48)">
          <Hill bottom={900} pts={FAR} fill="#CADBD2" edge="#DCE8E0" />
          <Hill bottom={900} pts={MID} fill="#B5CFAE" edge="#C8DDC2" />
        </g></Svg>
      </Layer>
      <Layer depth={14} z={1.05} shadow>
        <Svg><g transform="translate(0 -48)">
          <Hill bottom={900} pts={GROUND} fill="#A3C298" edge="#B7D3AD" />
          <Hill bottom={900} pts={LOWER} fill="#92B58C" edge="#A7C6A0" />
        </g></Svg>
      </Layer>

      <Layer depth={18} z={1.06}>
        <Svg><g transform="translate(0 -48)">
          <Row list={BACK} d0={1.6} step={0.25} off={1} />
        </g></Svg>
      </Layer>

      <Layer depth={22} z={1.08} origin="50% 40%">
        <Svg><g transform="translate(0 -48)">
          <Tree x={200} y={482} s={1} delay={0.3} cols={[P.rose, P.blush, P.lav]} />
        </g></Svg>
      </Layer>

      <Layer depth={28} z={1.1}>
        <Svg><g transform="translate(0 -48)">
          <Row list={MIDROW} d0={2.4} step={0.35} />
        </g></Svg>
      </Layer>

      <Layer depth={34} z={1.14}>
        <Svg><g transform="translate(0 -48)">
          <Row list={FRONT} d0={3.4} step={0.4} off={2} />
          <Grass x={0} y={520} s={1.1} n={10} h={50} seed={4} />
          <Grass x={400} y={520} s={1.1} n={10} h={54} seed={12} />
        </g></Svg>
      </Layer>

      <Layer depth={38} z={1.1}>
        <Svg><g transform="translate(0 -48)">
          <Butterfly x={90} y={330} s={1.2} c1={P.lav} c2={P.lavDeep} v={3} />
          <Butterfly x={300} y={400} s={1.1} c1={P.peach} c2={P.rose} v={1} />
          <Butterfly x={170} y={470} s={0.9} c1={P.ivory} c2={P.blush} v={2} />
        </g></Svg>
      </Layer>

      <Petals count={20} delay={2.2} seed={8} cols={[P.blush, P.ivory, P.lav, P.rose]} />

      <TextPanel pos="bottom" scrim="rgba(253,246,235,.95)">
        <Fade delay={0.5} v="plain">
          <p className="eyebrow">May happiness always find you</p>
        </Fade>
        <h2 className="blessing">
          <Words delay={1.0} step={0.12} v="blur">
            May happiness find you in the little things.
          </Words>
        </h2>
        <Fade delay={2.8} className="support">
          May your days be filled with genuine laughter, little surprises, warm conversations and moments that make ordinary life extraordinary.
        </Fade>
        <Fade delay={4.2} v="mask" className="quote">
          Sometimes the greatest happiness lives in the smallest moments.
        </Fade>
      </TextPanel>
    </SceneRoot>
  );
}
