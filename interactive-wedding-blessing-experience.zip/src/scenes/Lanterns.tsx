import type { CSSProperties } from "react";
import { Cloud, Fireflies, Flower, FLOWER_SETS, Garland, Hill, Lantern, Pole, Sparkles, Sun, Svg, Walkway, type Pt, type Rp } from "../art";
import { Fade, Layer, SceneRoot, TextPanel, Words, useReadyAfter, type SceneProps } from "../ui";

const FAR: Pt[] = [[-20, 372], [70, 352], [160, 366], [250, 348], [340, 362], [420, 350]];
const MID: Pt[] = [[-20, 410], [90, 388], [190, 404], [290, 384], [420, 402]];
const NEAR: Pt[] = [[-20, 448], [110, 424], [220, 440], [330, 420], [420, 438]];
const GROUND: Pt[] = [[-20, 492], [120, 470], [260, 484], [420, 466]];

const PATH: Rp[] = [
  [200, 372, 4],
  [204, 392, 9],
  [194, 416, 16],
  [208, 450, 28],
  [200, 510, 50],
  [200, 580, 76],
];

const POSTS: [number, number, number, number][] = [
  [172, 400, 0.5, 5.0],
  [232, 402, 0.5, 5.4],
  [148, 428, 0.72, 5.8],
  [256, 430, 0.72, 6.2],
];

const SKYLANTERNS: [number, number, number, number][] = [
  [70, 440, 0.7, 0],
  [318, 430, 0.62, 7],
  [236, 452, 0.5, 13],
  [140, 446, 0.55, 19],
];

export default function Lanterns({ ready }: SceneProps) {
  useReadyAfter(ready, 3400);
  return (
    <SceneRoot className="s5">
      <Layer depth={0} z={1.02} pd={22}>
        <Svg>
          <defs>
            <linearGradient id="s5sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#8A84B6" />
              <stop offset=".24" stopColor="#B3A2CE" />
              <stop offset=".42" stopColor="#E3B5BA" />
              <stop offset=".54" stopColor="#F6C7A0" />
            </linearGradient>
            <linearGradient id="s5gold" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#F9D69C" />
              <stop offset=".35" stopColor="#F9C592" />
              <stop offset=".55" stopColor="#F5B79A" />
            </linearGradient>
          </defs>
          <rect width="400" height="800" fill="url(#s5sky)" />
          <rect width="400" height="800" fill="url(#s5gold)" className="sky-fade" />
          <g className="fade-in" style={{ animationDelay: "5s" }}>
            <Sparkles list={[[50, 60, 0.7], [130, 110, 0.5], [240, 50, 0.6], [330, 96, 0.8], [372, 40, 0.5], [190, 160, 0.5], [90, 190, 0.45], [290, 190, 0.5]]} />
          </g>
        </Svg>
      </Layer>

      <Layer depth={3} z={1.03} pd={22}>
        <Svg><g transform="translate(0 -34)">
          <g className="sunset">
            <Sun x={200} y={338} r={30} color="#FFD9A0" rays={false} />
          </g>
        </g></Svg>
      </Layer>

      <Layer depth={7} z={1.03} pd={22}>
        <Svg><g transform="translate(0 -34)">
          <Cloud x={10} y={286} s={0.8} fill="#F5C5BA" op={0.75} dur={50} />
          <Cloud x={250} y={250} s={0.65} fill="#F3BCBA" op={0.7} dur={42} />
          <Cloud x={120} y={330} s={0.4} fill="#F8CFB8" op={0.7} dur={36} />
        </g></Svg>
      </Layer>

      <Layer depth={10} z={1.04} shadow>
        <Svg><g transform="translate(0 -34)">
          <Hill bottom={900} pts={FAR} fill="#C7B0D2" edge="#D8C6E0" />
        </g></Svg>
      </Layer>
      <Layer depth={14} z={1.05} shadow>
        <Svg><g transform="translate(0 -34)">
          <Hill bottom={900} pts={MID} fill="#AD98C3" edge="#C0AED3" />
        </g></Svg>
      </Layer>
      <Layer depth={18} z={1.07} shadow>
        <Svg><g transform="translate(0 -34)">
          <Hill bottom={900} pts={NEAR} fill="#86A096" edge="#9BB5AB" />
          <Hill bottom={900} pts={GROUND} fill="#6E917E" edge="#85A794" />
        </g></Svg>
      </Layer>

      <Layer depth={20} z={1.08}>
        <Svg><g transform="translate(0 -34)">
          <Walkway pts={PATH} fill="#EAD6AE" edge="#D8BE8A" delay={0.5} glowColor="#FFD58A" />
          {[[30, 468, 0.5], [78, 480, 0.55], [330, 478, 0.55], [376, 470, 0.5]].map(([x, y, s], i) => (
            <Flower key={i} x={x} y={y} s={s} h={40} d={1 + i * 0.4} {...FLOWER_SETS[(i * 2 + 1) % 6]} />
          ))}
        </g></Svg>
      </Layer>

      <Layer depth={24} z={1.1}>
        <Svg><g transform="translate(0 -34)">
          {POSTS.map(([x, y, s, d], i) => (
            <g key={i}>
              <Pole x={x} y={y + 22 * s} h={46 * s} w={4 * s + 1} />
              <Lantern x={x} y={y} s={s} delay={d} />
            </g>
          ))}
        </g></Svg>
      </Layer>

      <Layer depth={30} z={1.12}>
        <Svg><g transform="translate(0 -34)">
          <Pole x={26} y={128} h={340} w={7} />
          <Pole x={374} y={128} h={340} w={7} />
          <Garland x1={26} y1={134} x2={374} y2={146} sag={44} items={7} delay={1.0} s={1} />
          <Garland x1={26} y1={236} x2={374} y2={230} sag={34} items={6} delay={2.4} s={0.82} color="#F4A98A" />
        </g></Svg>
      </Layer>

      <Layer depth={36} z={1.1} pd={20}>
        <Svg><g transform="translate(0 -34)">
          <Fireflies n={20} seed={5} area={[10, 230, 390, 470]} />
        </g></Svg>
      </Layer>

      <Layer depth={14} z={1} pd={20}>
        <Svg><g transform="translate(0 -34)">
          {SKYLANTERNS.map(([x, y, s, d], i) => (
            <g key={i} transform={`translate(${x} ${y})`}>
              <g className="skyl" style={{ "--sd": `${d}s`, "--sx": `${i % 2 ? -40 : 36}px` } as CSSProperties}>
                <Lantern x={0} y={0} s={s} delay={d + 0.4} color="#F8B070" />
              </g>
            </g>
          ))}
        </g></Svg>
      </Layer>

      <div className="dusk-tint" />
      <div className="lantern-wash" />

      <TextPanel pos="bottom" tone="light" scrim="rgba(70,56,104,.93)">
        <Fade delay={0.5} v="plain">
          <p className="eyebrow">May your world always stay bright</p>
        </Fade>
        <h2 className="blessing">
          <Words delay={1.0} step={0.12} v="glow">
            May your life always have reasons to shine.
          </Words>
        </h2>
        <Fade delay={2.8} className="support">
          May your home be filled with warmth, your hearts with understanding, your days with kindness and your years with countless moments worth remembering.
        </Fade>
        <Fade delay={4.4} v="mask" className="quote">
          Love grows strongest where kindness and respect are never in short supply.
        </Fade>
      </TextPanel>
    </SceneRoot>
  );
}
