import { useEffect, useRef, useState, type CSSProperties } from "react";
import { sound } from "../audio";
import { Cloud, Flower, FlowerHead, FLOWER_SETS, Grass, Hill, P, Svg, type Pt } from "../art";
import { Fade, Heart, Layer, Petals, SceneRoot, TextPanel, Words, type SceneProps } from "../ui";

const XS = [58, 129, 200, 271, 342];
const WORDS = ["Joy", "Patience", "Kindness", "Laughter", "Togetherness"];
const SETS = [FLOWER_SETS[0], FLOWER_SETS[1], FLOWER_SETS[2], FLOWER_SETS[3], FLOWER_SETS[5]];
const SOIL_Y = 612;

const FAR: Pt[] = [[-20, 372], [70, 346], [170, 362], [270, 340], [350, 358], [420, 344]];
const MID: Pt[] = [[-20, 430], [110, 398], [230, 420], [330, 394], [420, 414]];
const GRASS: Pt[] = [[-20, 500], [120, 476], [260, 492], [420, 472]];

const sty = (o: Record<string, string | number>) => o as CSSProperties;

function Soil() {
  // scalloped paper-cut soil strip
  let d = "M-20,820L-20,596";
  for (let x = -20; x < 430; x += 36) d += `Q${x + 18},${578} ${x + 36},596`;
  d += "L430,820Z";
  return (
    <g>
      <path d={d} fill="#B79C88" />
      <path d={d} fill="#C8AE9A" transform="translate(0 -5)" opacity=".5" />
      <rect x="-20" y="640" width="440" height="200" fill="#A98C78" opacity=".55" />
      {[[30, 700], [120, 740], [210, 690], [300, 750], [380, 700], [80, 780], [250, 790], [350, 780]].map(([x, y], i) => (
        <ellipse key={i} cx={x} cy={y} rx={6 + (i % 3) * 2} ry="3" fill="#8F7360" opacity=".5" />
      ))}
    </g>
  );
}

function Can({ x, y, pouring }: { x: number; y: number; pouring: boolean }) {
  return (
    <g style={{ transform: `translate(${x}px, ${y}px) rotate(${pouring ? 22 : 0}deg)`, transition: "transform .6s cubic-bezier(.3,1.25,.5,1)" }}>
      <g className="bob">
        <path d="M-2,-6C-24,-18 -24,18 -2,10" fill="none" stroke="#7DA3BD" strokeWidth="5" strokeLinecap="round" />
        <path d="M34,8L62,-12L66,-6L40,18Z" fill="#7DA3BD" />
        <ellipse cx="66" cy="-9" rx="4.5" ry="7" transform="rotate(35 66 -9)" fill="#6C93AE" />
        <rect x="-4" y="-10" width="46" height="36" rx="8" fill="#9DC0D6" />
        <rect x="-4" y="-10" width="46" height="9" rx="4.5" fill="#C3DAEA" />
        <path d="M8,8Q19,0 30,8" stroke="#fff" strokeWidth="2.4" fill="none" opacity=".6" strokeLinecap="round" />
        <circle cx="19" cy="17" r="3.2" fill={P.rose} />
      </g>
    </g>
  );
}

function Plant({ i, s, next, onTap }: { i: number; s: number; next: boolean; onTap: () => void }) {
  const x = XS[i];
  const set = SETS[i];
  const done = s === 3;
  return (
    <g transform={`translate(${x} ${SOIL_Y})`}>
      <ellipse cx="0" cy="2" rx="32" ry="10" fill="#8E7260" />
      <ellipse cx="0" cy="-1" rx="28" ry="8.5" fill="#A5826C" />
      {s === 0 && (
        <g>
          <circle cy="-2" r="5.5" fill={P.gold} className="seed" />
          <circle cy="-2" r="12" fill="url(#g-sun)" className="glow-breathe" />
        </g>
      )}
      {s === 1 && (
        <g key="s1" className="grow" style={{ animationDuration: ".7s" }}>
          <path d="M0,0C0,-10 2,-22 0,-34" stroke={P.sageDeep} strokeWidth="3" fill="none" strokeLinecap="round" />
          <path d="M0,-30q-14,-2 -18,-14q12,0 18,14z" fill={P.sageMid} />
          <path d="M0,-34q14,-2 18,-14q-12,0 -18,14z" fill={P.sage} />
        </g>
      )}
      {s === 2 && (
        <g key="s2">
          <g className="grow" style={{ animationDuration: ".7s" }}>
            <path d="M0,0C2,-20 -2,-44 0,-62" stroke={P.sageDeep} strokeWidth="3.2" fill="none" strokeLinecap="round" />
            <path d="M0,-24q-16,-2 -20,-15q13,0 20,15z" fill={P.sageMid} />
            <path d="M0,-40q16,-2 20,-15q-13,0 -20,15z" fill={P.sage} />
          </g>
          <g transform="translate(0 -70)">
            <g className="bloom" style={{ animationDuration: ".8s" }}>
              <path d="M0,10C-16,4 -14,-16 0,-24C14,-16 16,4 0,10Z" fill={set.c1} />
              <path d="M0,10C-7,4 -6,-12 0,-24C6,-12 7,4 0,10Z" fill={set.c2} />
            </g>
          </g>
        </g>
      )}
      {done && (
        <g key="s3">
          <g className="grow" style={{ animationDuration: ".5s" }}>
            <path d="M0,0C2,-26 -2,-58 0,-86" stroke={P.sageDeep} strokeWidth="3.4" fill="none" strokeLinecap="round" />
            <path d="M0,-28q-18,-2 -23,-17q15,0 23,17z" fill={P.sageMid} />
            <path d="M0,-50q18,-2 23,-17q-15,0 -23,17z" fill={P.sage} />
          </g>
          <g transform="translate(0 -92)">
            <g className="bloom" style={{ animationDuration: "1s" }}>
              <FlowerHead r={27} c1={set.c1} c2={set.c2} center={set.center} n={set.n + 1} fat={0.52} />
            </g>
            {[0, 1, 2, 3, 4, 5].map((k) => (
              <circle key={k} r="3" fill="#FFE9A8" className="burst" style={sty({ "--bx": `${Math.cos((k * Math.PI) / 3) * 44}px`, "--by": `${Math.sin((k * Math.PI) / 3) * 44}px` })} />
            ))}
          </g>
          <text className="plant-label" x="0" y={-136 - (i % 2) * 24} textAnchor="middle" style={{ animationDelay: ".5s" }}>
            {WORDS[i]}
          </text>
        </g>
      )}
      {next && !done && (
        <g transform="translate(0 -30)" pointerEvents="none">
          <circle r="16" className="svg-ring" />
          <circle r="16" className="svg-ring r2" />
          <circle r="4.5" fill="#fff" opacity=".9" />
        </g>
      )}
      <rect x="-34" y="-190" width="68" height="214" fill="transparent" onClick={onTap} style={{ cursor: done ? "default" : "pointer" }} role="button" aria-label={`Water seed ${i + 1}`} tabIndex={0} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && onTap()} />
    </g>
  );
}

function Bouquet() {
  const pos: [number, number, number][] = [[24, 34, -22], [96, 34, 22], [60, 20, 0], [40, 46, -10], [80, 46, 10]];
  return (
    <svg viewBox="0 0 120 100" className="cert-bouquet" aria-hidden="true">
      {pos.map(([x, y], i) => (
        <path key={i} d={`M${x},${y}Q${(x + 60) / 2},${(y + 80) / 2 + 6} 60,84`} stroke={P.sageDeep} strokeWidth="2.4" fill="none" strokeLinecap="round" />
      ))}
      {pos.map(([x, y], i) => (
        <g key={i} transform={`translate(${x} ${y})`}>
          <FlowerHead r={i === 2 ? 17 : 15} c1={SETS[i].c1} c2={SETS[i].c2} center={SETS[i].center} n={SETS[i].n} fat={0.55} />
        </g>
      ))}
      <path d="M60,80L44,92L52,96L60,86L68,96L76,92Z" fill={P.roseDeep} />
      <rect x="52" y="76" width="16" height="9" rx="3" fill={P.rose} />
    </svg>
  );
}

export default function Game({ ready }: SceneProps) {
  const [st, setSt] = useState([0, 0, 0, 0, 0]);
  const [can, setCan] = useState<{ i: number; n: number } | null>(null);
  const [phase, setPhase] = useState<"play" | "award">("play");
  const timers = useRef<number[]>([]);
  const readyRef = useRef(ready);
  readyRef.current = ready;

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  useEffect(() => {
    if (phase !== "play" || !st.every((v) => v === 3)) return;
    const id = window.setTimeout(() => {
      setPhase("award");
      sound.sfx("award");
      readyRef.current();
    }, 1600);
    return () => clearTimeout(id);
  }, [st, phase]);

  const bloomed = st.filter((v) => v === 3).length;
  const nextIdx = st.findIndex((v) => v < 3);

  const tap = (i: number) => {
    if (phase !== "play" || st[i] >= 3) return;
    sound.sfx("water");
    const nv = st[i] + 1;
    setCan((c) => ({ i, n: (c?.n ?? 0) + 1 }));
    // plants respond when the water reaches them
    timers.current.push(
      window.setTimeout(() => {
        setSt((prev) => {
          const copy = [...prev];
          copy[i] = Math.max(copy[i], nv);
          return copy;
        });
        sound.sfx(nv === 3 ? "bloom" : "pop");
      }, 650)
    );
  };

  const canX = can ? XS[can.i] - 52 : 150;
  const canY = can ? 440 : 470;

  return (
    <SceneRoot className="s6">
      <Layer depth={0} z={1.02} pd={20}>
        <Svg>
          <defs>
            <linearGradient id="s6sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#EBD9EA" />
              <stop offset=".3" stopColor="#F6DAD8" />
              <stop offset=".52" stopColor="#FCEBD6" />
            </linearGradient>
          </defs>
          <rect width="400" height="800" fill="url(#s6sky)" />
          <circle cx="90" cy="260" r="150" fill="url(#g-white)" opacity=".6" />
        </Svg>
      </Layer>
      <Layer depth={6} z={1.03} pd={22}>
        <Svg>
          <Cloud x={230} y={230} s={0.8} fill="#FFF6EA" op={0.9} dur={48} />
          <Cloud x={10} y={330} s={0.6} fill="#FFF6EA" op={0.85} dur={40} />
        </Svg>
      </Layer>
      <Layer depth={10} z={1.04} shadow>
        <Svg>
          <Hill pts={FAR} fill="#D2C6E2" edge="#E1D8EC" />
          <Hill pts={MID} fill="#BCCFB4" edge="#CFDEC7" />
          <Hill pts={GRASS} fill="#A6C29B" edge="#BAD3B0" />
        </Svg>
      </Layer>
      <Layer depth={14} z={1.02} shadow>
        <Svg>
          <Soil />
        </Svg>
      </Layer>

      <Layer depth={0} z={1} pd={1}>
        <Svg>
          <g>
            <Grass x={8} y={600} s={1.1} n={9} h={52} seed={31} />
            <Grass x={394} y={600} s={1.1} n={9} h={52} seed={37} />
            <Flower x={20} y={606} s={0.6} h={44} d={0.4} {...FLOWER_SETS[4]} />
            <Flower x={384} y={606} s={0.6} h={44} d={0.8} {...FLOWER_SETS[2]} />
            {st.map((s, i) => (
              <Plant key={i} i={i} s={s} next={i === nextIdx && phase === "play"} onTap={() => tap(i)} />
            ))}
            {can && (
              <g key={can.n} transform={`translate(${XS[can.i] + 8} ${SOIL_Y - 152})`} pointerEvents="none">
                {[0, 1, 2, 3, 4, 5].map((k) => (
                  <circle key={k} cx={k * 2.2 - 6} r="2.6" fill="#9CC6E2" className="drop" style={{ animationDelay: `${0.45 + k * 0.07}s` }} />
                ))}
              </g>
            )}
            {phase === "play" && <Can x={canX} y={canY} pouring={!!can} />}
          </g>
        </Svg>
      </Layer>

      {phase === "play" && (
        <TextPanel pos="top" scrim="rgba(255,245,235,.7)">
          <Fade delay={0.3} v="plain">
            <p className="eyebrow">A little something to play with</p>
          </Fade>
          <h2 className="blessing">
            <Words delay={0.7} step={0.1} v="pop">
              Help the little wishes grow.
            </Words>
          </h2>
          <Fade delay={1.9} className="support">
            Tap a seed to water it, and watch each one bloom into a wish.
          </Fade>
          <Fade delay={2.4} v="plain" className="count">
            {bloomed} of 5 in bloom
          </Fade>
        </TextPanel>
      )}

      {phase === "award" && (
        <>
          <div className="award-dim" />
          <Petals count={30} delay={0} seed={44} cols={[P.blush, P.ivory, P.peach, P.lav, P.gold]} size={3} />
          <div className="cert-wrap">
            <div className="cert">
              <div className="cert-in">
                <Bouquet />
                <p className="cert-kicker">Official award</p>
                <h3 className="cert-title">Bride of the Year</h3>
                <p className="cert-to">
                  presented to <b>Ravleen Didi</b> <Heart size={0.9} />
                </p>
                <p className="cert-for">for outstanding radiance, grace and general wonderfulness</p>
                <ul className="cert-list">
                  <li>Unlimited second helpings of wedding dessert</li>
                  <li>A lifetime supply of good wishes</li>
                  <li>The best seat at every celebration</li>
                </ul>
                <div className="cert-seal">
                  <span>Valid</span>
                  <span>for life</span>
                </div>
                <p className="cert-sign">Signed, The Little Garden</p>
              </div>
            </div>
          </div>
        </>
      )}
    </SceneRoot>
  );
}
