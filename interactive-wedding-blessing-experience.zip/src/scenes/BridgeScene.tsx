import { Bird, Bridge, Butterfly, Cloud, Flower, FLOWER_SETS, Grass, Hill, LilyPad, P, PineTree, RoundTree, Stream, Svg, type Pt, type Rp } from "../art";
import { Fade, Layer, SceneRoot, TextPanel, Words, useReadyAfter, type SceneProps } from "../ui";

export const STREAM: Rp[] = [
  [200, 450, 8],
  [208, 475, 30],
  [192, 530, 80],
  [196, 600, 130],
  [210, 690, 170],
  [205, 810, 230],
];

const FAR: Pt[] = [[-20, 408], [60, 392], [150, 404], [240, 388], [330, 402], [420, 392]];
const MID: Pt[] = [[-20, 446], [90, 426], [190, 440], [300, 422], [420, 440]];
const BANK: Pt[] = [[-20, 478], [100, 456], [200, 448], [300, 456], [420, 476]];
const BANK2: Pt[] = [[-20, 540], [110, 516], [200, 522], [300, 514], [420, 538]];

const EDGE: [number, number, number][] = [
  [70, 616, 0.55], [94, 628, 0.5], [56, 646, 0.62], [122, 646, 0.45], [330, 618, 0.55], [306, 630, 0.5], [346, 648, 0.62], [280, 648, 0.45], [26, 624, 0.5], [376, 626, 0.5],
];

export default function BridgeScene({ ready }: SceneProps) {
  useReadyAfter(ready, 3200);
  return (
    <SceneRoot className="s4">
      <Layer depth={0} z={1.02} pd={20}>
        <Svg>
          <defs>
            <linearGradient id="s4sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#B4D0E5" />
              <stop offset=".28" stopColor="#D2E4EC" />
              <stop offset=".5" stopColor="#F4EEDF" />
            </linearGradient>
          </defs>
          <rect width="400" height="800" fill="url(#s4sky)" />
        </Svg>
      </Layer>

      <Layer depth={5} z={1.03} pd={22}>
        <Svg>
          <Cloud x={230} y={190} s={0.8} op={0.9} dur={48} />
          <Cloud x={-10} y={300} s={0.7} op={0.85} dur={56} />
          <Cloud x={160} y={352} s={0.45} op={0.8} dur={42} />
          <Bird x={80} y={120} s={1} delay={0} />
          <Bird x={108} y={134} s={0.7} delay={0.3} />
          <Bird x={300} y={250} s={0.8} delay={0.6} />
        </Svg>
      </Layer>

      <Layer depth={8} z={1.03} tx={-4} shadow>
        <Svg>
          <Hill pts={FAR} fill="#BFD2D8" edge="#D2E0E3" />
          <rect x="-10" y="396" width="420" height="50" fill="url(#g-mist)" opacity=".7" />
        </Svg>
      </Layer>
      <Layer depth={12} z={1.05} tx={-10} shadow>
        <Svg>
          <Hill pts={MID} fill="#A9C7B3" edge="#BDD6C5" />
          <PineTree x={48} y={448} s={0.5} fill={P.sageDeep} fill2={P.sageMid} />
          <PineTree x={74} y={444} s={0.38} fill={P.sageDark} fill2={P.sageDeep} />
          <RoundTree x={344} y={446} s={0.5} />
          <RoundTree x={316} y={442} s={0.38} fill={P.sageDeep} fill2={P.sageMid} />
        </Svg>
      </Layer>
      <Layer depth={17} z={1.08} tx={-16} shadow>
        <Svg>
          <Hill pts={BANK} fill="#98BB92" edge="#ADCCA6" />
          <Hill pts={BANK2} fill="#87AC85" edge="#9DBF9A" />
        </Svg>
      </Layer>

      <Layer depth={20} z={1.1} tx={-18}>
        <Svg>
          <Stream pts={STREAM} lines={7} delay={0.2} />
          <LilyPad x={176} y={702} s={0.9} d={4.4} />
          <LilyPad x={240} y={738} s={1.1} d={5} />
          <LilyPad x={204} y={772} s={1.2} d={5.6} bloom={false} />
        </Svg>
      </Layer>

      <Layer depth={24} z={1.1} tx={-18}>
        <Svg>
          <PineTree x={38} y={600} s={1.25} />
          <PineTree x={78} y={566} s={0.85} fill={P.sageDark} fill2={P.sageDeep} />
          <RoundTree x={362} y={598} s={1.3} />
          <RoundTree x={326} y={560} s={0.85} fill={P.sageDeep} fill2={P.sageMid} />
        </Svg>
      </Layer>

      <Layer depth={28} z={1.14} tx={-30} pd={18}>
        <Svg>
          <Bridge x={200} y={612} w={230} h={46} delay={1.0} />
        </Svg>
      </Layer>

      <Layer depth={32} z={1.16} tx={-34}>
        <Svg>
          {EDGE.map(([x, y, s], i) => (
            <Flower key={i} x={x} y={y} s={s} h={40 + (i % 3) * 8} lean={((i % 5) - 2) * 3} d={3.2 + i * 0.3} {...FLOWER_SETS[(i + 1) % 6]} />
          ))}
          <Butterfly x={140} y={560} s={1} c1={P.peach} c2={P.rose} v={2} />
        </Svg>
      </Layer>

      <Layer depth={40} z={1.22} tx={-48}>
        <Svg>
          <Grass x={10} y={818} s={1.6} n={11} h={78} seed={6} />
          <Grass x={392} y={818} s={1.6} n={11} h={80} seed={14} />
          <Flower x={40} y={820} s={1.5} h={92} lean={5} d={4.4} {...FLOWER_SETS[4]} r={13} />
          <Flower x={364} y={822} s={1.6} h={98} lean={-5} d={4.8} {...FLOWER_SETS[3]} r={13} />
        </Svg>
      </Layer>

      <TextPanel pos="top" scrim="rgba(240,246,246,.8)">
        <Fade delay={0.3} v="plain">
          <p className="eyebrow">For the journey ahead</p>
        </Fade>
        <h2 className="blessing">
          <Words delay={0.8} step={0.1} v="mask">
            May you always find strength in togetherness.
          </Words>
        </h2>
        <Fade delay={2.2} className="support">
          May you understand each other in silence, stand beside each other during difficult moments, celebrate every little victory and grow stronger through every season of life.
        </Fade>
        <Fade delay={3.6} v="mask" className="quote">
          A beautiful journey isn’t one without storms, but one where you never have to face them alone.
        </Fade>
      </TextPanel>
    </SceneRoot>
  );
}
