import { Butterfly, Cloud, Flower, FLOWER_SETS, Grass, Hill, Meadow, P, RoundTree, Sun, Svg, Walkway, type Rp, type Pt } from "../art";
import { Fade, Layer, Petals, SceneRoot, TextPanel, Words, useReadyAfter, type SceneProps } from "../ui";

export const SUNRISE_PATH: Rp[] = [
  [205, 470, 6],
  [214, 505, 14],
  [190, 545, 30],
  [176, 590, 54],
  [210, 650, 84],
  [232, 720, 120],
  [200, 800, 170],
];

const FAR: Pt[] = [[-20, 470], [60, 450], [140, 462], [210, 449], [290, 441], [360, 452], [420, 440]];
const MID: Pt[] = [[-20, 524], [80, 490], [170, 507], [260, 482], [340, 497], [420, 480]];
const NEAR: Pt[] = [[-20, 592], [90, 550], [200, 577], [300, 547], [420, 572]];
const FORE: Pt[] = [[-20, 700], [70, 668], [170, 690], [260, 676], [340, 662], [420, 690]];

// [x, y, scale] — left and right of the path, small near the horizon
const MEADOW: [number, number, number][] = [
  [150, 575, 0.4], [262, 590, 0.4], [128, 612, 0.5], [286, 626, 0.5], [100, 652, 0.62], [316, 662, 0.62],
  [42, 640, 0.55], [372, 650, 0.55], [60, 704, 0.8], [350, 708, 0.8], [112, 726, 0.75], [322, 744, 0.75],
  [24, 764, 0.95], [376, 778, 0.95], [88, 782, 0.9], [312, 792, 0.9], [190, 520, 0.2], [236, 516, 0.22], [120, 512, 0.24], [290, 505, 0.24],
];

export default function Sunrise({ ready }: SceneProps) {
  useReadyAfter(ready, 2600);
  return (
    <SceneRoot className="s2">
      <Layer depth={0} z={1.02} pd={20}>
        <Svg>
          <defs>
            <linearGradient id="s2sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#E6D6EA" />
              <stop offset=".24" stopColor="#F5DAD9" />
              <stop offset=".47" stopColor="#FAD1AE" />
              <stop offset=".6" stopColor="#FFE9C6" />
            </linearGradient>
          </defs>
          <rect width="400" height="800" fill="url(#s2sky)" />
        </Svg>
      </Layer>

      <Layer depth={3} z={1.03} pd={20}>
        <Svg>
          <g className="sunrise">
            <Sun x={200} y={412} r={36} />
          </g>
        </Svg>
      </Layer>

      <Layer depth={7} z={1.03} pd={22}>
        <Svg>
          <Cloud x={20} y={236} s={0.95} fill="#FFF3E4" op={0.8} dur={50} />
          <Cloud x={238} y={300} s={0.7} fill="#FFF3E4" op={0.75} dur={38} />
          <Cloud x={150} y={380} s={0.5} fill="#FFF6E6" op={0.7} dur={44} />
        </Svg>
      </Layer>

      <Layer depth={10} z={1.04} shadow>
        <Svg>
          <Hill pts={FAR} fill="#CDBFE0" edge="#DDD2EA" />
        </Svg>
      </Layer>
      <Layer depth={14} z={1.06} shadow>
        <Svg>
          <Hill pts={MID} fill="#BBCEB2" edge="#CFDDC6" />
          <RoundTree x={40} y={518} s={0.55} fill={P.sageMid} fill2={P.sage} />
          <RoundTree x={78} y={506} s={0.4} fill={P.sageDeep} fill2={P.sageMid} />
          <RoundTree x={352} y={500} s={0.5} fill={P.sageMid} fill2={P.sage} />
          <RoundTree x={316} y={494} s={0.36} fill={P.sageDeep} fill2={P.sageMid} />
        </Svg>
      </Layer>
      <Layer depth={20} z={1.08} shadow>
        <Svg>
          <Hill pts={NEAR} fill="#A4BE9C" edge="#B8CFB0" />
          <Hill pts={FORE} fill="#86A583" edge="#9BB798" />
        </Svg>
      </Layer>

      <Layer depth={22} z={1.1}>
        <Svg>
          <Walkway pts={SUNRISE_PATH} delay={0.3} />
        </Svg>
      </Layer>

      <Layer depth={26} z={1.12}>
        <Svg>
          <Meadow list={MEADOW} delay={1.2} spread={4.4} />
        </Svg>
      </Layer>

      <Layer depth={32} z={1.1}>
        <Svg>
          <Butterfly x={118} y={540} s={1.1} c1={P.blush} c2={P.rose} v={1} />
          <Butterfly x={270} y={575} s={0.95} c1={P.lav} c2={P.ivory} v={2} />
        </Svg>
      </Layer>

      <Layer depth={42} z={1.22}>
        <Svg>
          <Grass x={14} y={812} s={1.5} n={11} h={70} seed={2} />
          <Grass x={388} y={812} s={1.5} n={11} h={74} seed={9} />
          <Flower x={44} y={816} s={1.5} h={92} lean={6} d={3.2} {...FLOWER_SETS[0]} r={13} />
          <Flower x={366} y={818} s={1.6} h={98} lean={-6} d={3.8} {...FLOWER_SETS[1]} r={13} />
          <Flower x={96} y={826} s={1.2} h={70} lean={-3} d={4.2} {...FLOWER_SETS[2]} r={12} />
        </Svg>
      </Layer>

      <div className="dawn-tint" />
      <div className="sun-wash" />
      <Petals count={11} delay={3} seed={3} />

      <TextPanel pos="top" scrim="rgba(255,244,230,.72)">
        <Fade delay={0.3} v="plain">
          <p className="eyebrow">A beautiful beginning</p>
        </Fade>
        <h2 className="blessing">
          <Words delay={0.9} step={0.1} v="rise">
            Every beautiful chapter begins with a little hope.
          </Words>
        </h2>
        <Fade delay={2.4} className="support">
          May this new chapter bring countless reasons to smile, peaceful mornings, unexpected happiness and beautiful memories.
        </Fade>
      </TextPanel>
    </SceneRoot>
  );
}
