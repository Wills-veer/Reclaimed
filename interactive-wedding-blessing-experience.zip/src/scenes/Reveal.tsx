import { Fade, Petals, SceneRoot, TextPanel, Words, useReadyAfter, type SceneProps } from "../ui";
import { Panorama } from "./Panorama";

export default function Reveal({ ready }: SceneProps) {
  useReadyAfter(ready, 15800);
  return (
    <SceneRoot className="s7">
      <Panorama />
      <Petals count={14} delay={8} seed={21} />

      <TextPanel pos="top" scrim="rgba(255,243,230,.6)" className="tp-compact">
        <h2 className="blessing sm">
          <Words delay={9.3} step={0.11} v="blur">
            Every beautiful life is made of little moments.
          </Words>
        </h2>
      </TextPanel>

      <TextPanel pos="bottom" scrim="rgba(253,246,235,.94)" className="tp-compact">
        <div className="beats">
          <Fade delay={10.6} className="beat">
            <b style={{ color: "#B96F7B" }}>Hope</b> gives us a beginning.
          </Fade>
          <Fade delay={11.6} className="beat">
            <b style={{ color: "#A27E35" }}>Happiness</b> gives us reasons to smile.
          </Fade>
          <Fade delay={12.6} className="beat">
            <b style={{ color: "#4F8260" }}>Patience</b> helps us through the journey.
          </Fade>
          <Fade delay={13.6} className="beat">
            And <b style={{ color: "#7B69B0" }}>kindness</b> makes the journey beautiful.
          </Fade>
        </div>
        <Fade delay={15.0} v="mask" className="finale">
          May every little step ahead become a beautiful memory.
        </Fade>
      </TextPanel>
    </SceneRoot>
  );
}
