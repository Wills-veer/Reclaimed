import { useEffect, useRef, useState } from "react";
import { sound } from "../audio";
import { Flower, FLOWER_SETS, Grass, Hill, P, Svg } from "../art";
import { Fade, Heart, Layer, Motes, SceneRoot, TapHint, Words, type SceneProps } from "../ui";

function HangingFlower({ x, h, s, d, set }: { x: number; h: number; s: number; d: number; set: number }) {
  return (
    <g transform={`translate(${x} -8) rotate(180)`}>
      <Flower x={0} y={0} s={s} h={h} d={d} r={14} lean={x % 2 ? 4 : -4} {...FLOWER_SETS[set]} />
    </g>
  );
}

function PopScene() {
  return (
    <svg viewBox="0 0 100 128" className="popscene" aria-hidden="true">
      <defs>
        <linearGradient id="pp-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#F6DAD8" />
          <stop offset="1" stopColor="#FFEFD4" />
        </linearGradient>
      </defs>
      <rect width="100" height="128" fill="url(#pp-sky)" />
      <g className="pp" style={{ ["--pd" as string]: "1.2s" }}>
        <circle cx="50" cy="56" r="13" fill="#FFE2A6" />
        <circle cx="50" cy="56" r="20" fill="#FFE2A6" opacity=".35" />
      </g>
      <g className="pp" style={{ ["--pd" as string]: "1.35s" }}>
        <path d="M0,86C14,70 30,74 44,82C58,68 80,66 100,80V128H0Z" fill="#C7B6DB" />
      </g>
      <g className="pp" style={{ ["--pd" as string]: "1.5s" }}>
        <path d="M0,100C20,86 40,96 60,90C78,86 90,92 100,96V128H0Z" fill="#A9C2A1" />
      </g>
      <g className="pp" style={{ ["--pd" as string]: "1.7s" }}>
        <rect x="21" y="78" width="3" height="20" fill="#A18570" />
        <circle cx="22.5" cy="72" r="11" fill="#E9B4B4" />
        <circle cx="18" cy="75" r="7" fill="#F3D3CC" />
        <circle cx="28" cy="70" r="6" fill="#CDC2E3" />
      </g>
      <g className="pp" style={{ ["--pd" as string]: "1.9s" }}>
        <path d="M66,100V76Q66,66 74,66Q82,66 82,76V100" fill="none" stroke="#FBF5E9" strokeWidth="3" />
        <circle cx="66" cy="78" r="2.2" fill="#E9B4B4" />
        <circle cx="74" cy="67" r="2.2" fill="#F3D3CC" />
        <circle cx="82" cy="78" r="2.2" fill="#E9B4B4" />
      </g>
      <g className="pp" style={{ ["--pd" as string]: "2.05s" }}>
        <path d="M40,112l0,-8M52,114l0,-10M60,111l0,-7" stroke="#6F9276" strokeWidth="1.2" />
        <circle cx="40" cy="103" r="2.6" fill="#F3D3CC" />
        <circle cx="52" cy="102" r="3" fill="#F9CFA8" />
        <circle cx="60" cy="103" r="2.6" fill="#CDC2E3" />
      </g>
    </svg>
  );
}

export default function Invitation({ next }: SceneProps) {
  const [step, setStep] = useState(0); // 1 flap open, 2 card rise
  const [btn, setBtn] = useState(false);
  const [phase, setPhase] = useState<"idle" | "open" | "zoom">("idle");
  const timers = useRef<number[]>([]);
  const nextRef = useRef(next);
  nextRef.current = next;

  useEffect(() => {
    const t = timers.current;
    t.push(window.setTimeout(() => { setStep(1); sound.sfx("open"); }, 1500));
    t.push(window.setTimeout(() => setStep(2), 2350));
    t.push(window.setTimeout(() => setBtn(true), 5300));
    return () => t.forEach(clearTimeout);
  }, []);

  const begin = () => {
    if (phase !== "idle") return;
    setPhase("open");
    sound.sfx("chime");
    timers.current.push(window.setTimeout(() => setPhase("zoom"), 1900));
    timers.current.push(window.setTimeout(() => nextRef.current(), 3000));
  };

  return (
    <SceneRoot className={`inv ${phase} step${step}`}>
      <div className="inv-bg" />

      <Layer depth={6} z={1}>
        <Svg>
          <Hill pts={[[-20, 770], [100, 744], [220, 760], [330, 740], [420, 758]]} fill="#E6D9C8" />
          <HangingFlower x={26} h={120} s={1.2} d={0.3} set={0} />
          <HangingFlower x={84} h={70} s={1} d={0.9} set={1} />
          <HangingFlower x={374} h={130} s={1.25} d={0.6} set={5} />
          <HangingFlower x={316} h={64} s={1} d={1.1} set={2} />
          <HangingFlower x={190} h={36} s={0.8} d={1.2} set={3} />
        </Svg>
      </Layer>
      <Layer depth={16} z={1}>
        <Svg>
          <Grass x={10} y={810} s={1.6} n={11} h={74} seed={3} />
          <Grass x={392} y={810} s={1.6} n={11} h={78} seed={8} />
          <Flower x={36} y={812} s={1.5} h={110} lean={6} d={0.5} {...FLOWER_SETS[4]} r={14} />
          <Flower x={92} y={820} s={1.2} h={80} lean={-4} d={1.0} {...FLOWER_SETS[3]} r={13} />
          <Flower x={368} y={814} s={1.5} h={116} lean={-6} d={0.8} {...FLOWER_SETS[0]} r={14} />
          <Flower x={308} y={822} s={1.1} h={76} lean={4} d={1.3} {...FLOWER_SETS[1]} r={12} />
          <Flower x={196} y={826} s={0.9} h={50} d={1.6} {...FLOWER_SETS[2]} r={11} />
        </Svg>
      </Layer>
      <Motes count={22} />

      <div className="inv-tag">
        <Words delay={0.5} step={0.09} v="blur">
          A little world. A thousand good wishes. A beautiful beginning.
        </Words>
      </div>

      <div className="book-stage">
        <div className="book">
          <div className="book-block" />
          <div className="book-inner">
            <div className="page-glow" />
            <PopScene />
          </div>
          <div className="book-cover">
            <div className="cover-front">
              <svg viewBox="0 0 100 60" className="cover-emblem" aria-hidden="true">
                <path d="M26,56V28Q26,6 50,6Q74,6 74,28V56" fill="none" stroke={P.gold} strokeWidth="2.4" />
                <path d="M32,56V30Q32,13 50,13Q68,13 68,30V56" fill="none" stroke={P.gold} strokeWidth="1" opacity=".7" />
                {[[26, 40], [27, 26], [34, 14], [50, 7], [66, 14], [73, 26], [74, 40]].map(([x, y], i) => (
                  <circle key={i} cx={x} cy={y} r="3.2" fill={i % 2 ? P.blush : P.rose} />
                ))}
                <circle cx="50" cy="36" r="5" fill={P.gold} opacity=".9" />
              </svg>
              <p className="cover-title">
                A Little
                <br />
                Journey of
                <br />
                Blessings
              </p>
            </div>
            <div className="cover-back" />
          </div>
        </div>
      </div>

      <div className="env">
        <div className="env-back" />
        <div className="env-card">
          <div className="card-in">
            <p className="c1">For someone who deserves a thousand beautiful wishes...</p>
            <p className="c2">
              Ravleen Didi <Heart size={0.78} />
            </p>
            <p className="c3">A Little Journey of Blessings</p>
          </div>
        </div>
        <svg className="env-front" viewBox="0 0 200 126" preserveAspectRatio="none" aria-hidden="true">
          <path d="M0,0L0,126L100,64Z" fill="#EFE0CA" stroke="#DCC7A6" strokeWidth=".8" />
          <path d="M200,0L200,126L100,64Z" fill="#EFE0CA" stroke="#DCC7A6" strokeWidth=".8" />
          <path d="M0,126L100,58L200,126Z" fill="#F7ECDA" stroke="#DCC7A6" strokeWidth=".8" />
        </svg>
        <div className="env-flap" />
        <div className="seal">
          <Heart size={1} color="#FBE9E4" />
        </div>
      </div>

      {btn && phase === "idle" && (
        <div className="begin-wrap">
          <TapHint style={{ left: "50%", top: "50%" }} />
          <Fade v="plain" as="span">
            <button className="begin" onClick={begin}>
              Let’s begin
            </button>
          </Fade>
        </div>
      )}

      <div className="flood" />
    </SceneRoot>
  );
}
