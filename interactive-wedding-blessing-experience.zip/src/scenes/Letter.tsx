import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { FlowerHead, FLOWER_SETS, P } from "../art";
import { Heart, Motes, SceneRoot, type SceneProps } from "../ui";
import { Panorama } from "./Panorama";

const PARAS: string[] = [
  "Some people become a part of our journey through the lessons they teach, and some memories stay with us long after those lessons end.",
  "As you begin this beautiful new chapter of life, I wanted to send you something a little different, carrying a few wishes from the heart.",
  "May your married life be filled with endless happiness, mutual respect, understanding, laughter and countless beautiful memories.",
  "May you always find reasons to smile, strength in one another and warmth in every little moment.",
  "Thank you for being a part of my journey in your own special way.",
  "Wishing you a lifetime of happiness and togetherness.",
];

const wc = (s: string) => s.split(" ").length;

export default function Letter({ replay }: SceneProps) {
  const scroller = useRef<HTMLDivElement>(null);
  const touched = useRef(false);
  const [done, setDone] = useState(false);

  // sequential "writing" schedule
  const plan = useMemo(() => {
    let t = 2.4;
    const items: { d: number; dur: number }[] = [];
    const add = (words: number) => {
      const dur = 0.7 + words * 0.075;
      items.push({ d: t, dur });
      t += dur * 0.82 + 0.25;
    };
    add(3); // salutation
    PARAS.forEach((p) => add(wc(p)));
    add(8); // closing line
    add(5); // signature
    return { items, end: t + 0.6 };
  }, []);

  useEffect(() => {
    const ids: number[] = [];
    const el = scroller.current;
    plan.items.forEach((it, i) => {
      ids.push(
        window.setTimeout(() => {
          const node = el?.querySelector<HTMLElement>(`[data-i="${i}"]`);
          if (!el || !node || touched.current) return;
          const bottom = node.offsetTop + node.offsetHeight;
          const limit = el.scrollTop + el.clientHeight - 36;
          if (bottom > limit) el.scrollTo({ top: bottom - el.clientHeight + 48, behavior: "smooth" });
        }, it.d * 1000)
      );
    });
    ids.push(window.setTimeout(() => setDone(true), plan.end * 1000));
    return () => ids.forEach(clearTimeout);
  }, [plan]);

  const ink = (i: number): CSSProperties => ({ ["--d" as string]: `${plan.items[i].d}s`, ["--dur" as string]: `${plan.items[i].dur}s` }) as CSSProperties;

  return (
    <SceneRoot className="s8">
      <div className="letter-bg">
        <Panorama still />
      </div>
      <div className="letter-dusk" />
      <Motes count={20} seed={9} />

      <div className="letter-wrap">
        <div className="letter">
          <div className="crease c1" />
          <div className="crease c2" />
          <div
            className="letter-scroll"
            ref={scroller}
            onTouchStart={() => (touched.current = true)}
            onWheel={() => (touched.current = true)}
            onPointerDown={() => (touched.current = true)}
          >
            <p className="ink salute" data-i="0" style={ink(0)}>
              Dear Ravleen Didi,
            </p>
            {PARAS.map((p, i) => (
              <p key={i} className="ink lp" data-i={i + 1} style={ink(i + 1)}>
                {p}
              </p>
            ))}
            <p className="ink lp closing-line" data-i={PARAS.length + 1} style={ink(PARAS.length + 1)}>
              With lots of respect, affection and warm wishes,
            </p>
            <div className="ink sign" data-i={PARAS.length + 2} style={ink(PARAS.length + 2)}>
              <p className="sign-main">
                Your former students <Heart size={0.85} />
              </p>
              <p className="sign-names">Tashu &amp; Sanish</p>
            </div>
          </div>
        </div>
      </div>

      <div className={`finale-wrap ${done ? "on" : ""}`}>
        <svg viewBox="-30 -30 60 60" className="finale-flower" aria-hidden="true">
          <g className={done ? "bloom" : ""} style={{ animationDuration: "1.4s" }}>
            <FlowerHead r={22} c1={FLOWER_SETS[0].c1} c2={FLOWER_SETS[0].c2} center={P.gold} n={7} fat={0.52} />
          </g>
        </svg>
        <p className="finale-text">Here’s to a beautiful new beginning, Ravleen Didi.</p>
        <button className="replay" onClick={replay} tabIndex={done ? 0 : -1}>
          <svg viewBox="0 0 24 24" width="1.1em" height="1.1em" aria-hidden="true">
            <path d="M12 5V2L7 6l5 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7Z" fill="currentColor" />
          </svg>
          Replay the journey
        </button>
      </div>
    </SceneRoot>
  );
}
