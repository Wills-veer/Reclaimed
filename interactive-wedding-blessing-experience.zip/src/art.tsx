import type { CSSProperties, ReactNode } from "react";

/* ───────────── palette ───────────── */
export const P = {
  ivory: "#FBF5E9",
  cream: "#F5EBD7",
  sand: "#EBDDBF",
  sage: "#A9C2A1",
  sageMid: "#8FAE8C",
  sageDeep: "#6F9276",
  sageDark: "#55765E",
  blush: "#F3D3CC",
  rose: "#DDA5A5",
  roseDeep: "#C98089",
  lav: "#CDC2E3",
  lavDeep: "#A99BCB",
  sky: "#C3DAEA",
  skyDeep: "#92B8D2",
  peach: "#F9CFA8",
  peachDeep: "#F2A98A",
  gold: "#D9B873",
  goldDeep: "#B8914A",
  ink: "#4B3A3E",
  wood: "#CDB08A",
  woodDeep: "#A98A64",
};

export const LITE =
  typeof navigator !== "undefined" &&
  (((navigator as unknown as { hardwareConcurrency?: number }).hardwareConcurrency ?? 8) <= 3 ||
    ((navigator as unknown as { deviceMemory?: number }).deviceMemory ?? 8) <= 2);

export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ───────────── path helpers ───────────── */
export type Pt = [number, number];
export type Rp = [number, number, number];

export function smoothLine(pts: Pt[]) {
  let d = `M${pts[0][0]},${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] || p2;
    d += `C${(p1[0] + (p2[0] - p0[0]) / 6).toFixed(1)},${(p1[1] + (p2[1] - p0[1]) / 6).toFixed(1)} ${(p2[0] - (p3[0] - p1[0]) / 6).toFixed(1)},${(p2[1] - (p3[1] - p1[1]) / 6).toFixed(1)} ${p2[0]},${p2[1]}`;
  }
  return d;
}

export function hillPath(pts: Pt[], bottom = 820) {
  return `${smoothLine(pts)}L${pts[pts.length - 1][0]},${bottom}L${pts[0][0]},${bottom}Z`;
}

const cr = (a: number, b: number, c: number, d: number, t: number) =>
  0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t + (-a + 3 * b - 3 * c + d) * t * t * t);

export function densify(pts: Rp[], per = 8): Rp[] {
  const out: Rp[] = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[Math.min(pts.length - 1, i + 2)];
    for (let k = 0; k < per; k++) {
      const t = k / per;
      out.push([cr(p0[0], p1[0], p2[0], p3[0], t), cr(p0[1], p1[1], p2[1], p3[1], t), cr(p0[2], p1[2], p2[2], p3[2], t)]);
    }
  }
  out.push(pts[pts.length - 1]);
  return out;
}

function normals(d: Rp[]): Pt[] {
  return d.map((_, i) => {
    const a = d[Math.max(0, i - 1)];
    const b = d[Math.min(d.length - 1, i + 1)];
    const dx = b[0] - a[0];
    const dy = b[1] - a[1];
    const l = Math.hypot(dx, dy) || 1;
    return [-dy / l, dx / l] as Pt;
  });
}

export function ribbonPath(pts: Rp[]) {
  const d = densify(pts);
  const n = normals(d);
  const L = d.map((p, i) => `${(p[0] + (n[i][0] * p[2]) / 2).toFixed(1)},${(p[1] + (n[i][1] * p[2]) / 2).toFixed(1)}`);
  const R = d.map((p, i) => `${(p[0] - (n[i][0] * p[2]) / 2).toFixed(1)},${(p[1] - (n[i][1] * p[2]) / 2).toFixed(1)}`).reverse();
  return `M${L.join("L")}L${R.join("L")}Z`;
}

export function ribbonLine(pts: Rp[], f: number) {
  const d = densify(pts);
  const n = normals(d);
  return "M" + d.map((p, i) => `${(p[0] + n[i][0] * p[2] * f).toFixed(1)},${(p[1] + n[i][1] * p[2] * f).toFixed(1)}`).join("L");
}

function petalsPath(n: number, len: number, wid: number, off = 0) {
  let d = "";
  for (let i = 0; i < n; i++) {
    const a = ((off + (i * 360) / n) * Math.PI) / 180;
    const ca = Math.cos(a);
    const sa = Math.sin(a);
    const rot = (x: number, y: number) => `${(x * ca - y * sa).toFixed(1)},${(x * sa + y * ca).toFixed(1)}`;
    d += `M0,0C${rot(-wid, -len * 0.3)} ${rot(-wid * 0.8, -len * 0.95)} ${rot(0, -len)}C${rot(wid * 0.8, -len * 0.95)} ${rot(wid, -len * 0.3)} 0,0Z`;
  }
  return d;
}

const sty = (o: Record<string, string | number>) => o as CSSProperties;

/* ───────────── global defs (gradients shared by every svg) ───────────── */
export function GlobalDefs() {
  return (
    <svg width="0" height="0" style={{ position: "absolute" }} aria-hidden="true">
      <defs>
        <radialGradient id="g-sun">
          <stop offset="0" stopColor="#FFF3CF" stopOpacity=".95" />
          <stop offset=".35" stopColor="#FFDDA6" stopOpacity=".55" />
          <stop offset="1" stopColor="#FFC98A" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="g-lantern">
          <stop offset="0" stopColor="#FFD795" stopOpacity=".95" />
          <stop offset=".4" stopColor="#FFC27A" stopOpacity=".38" />
          <stop offset="1" stopColor="#FFB070" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="g-fly">
          <stop offset="0" stopColor="#FFF6B8" stopOpacity="1" />
          <stop offset=".35" stopColor="#FFE58A" stopOpacity=".5" />
          <stop offset="1" stopColor="#FFE58A" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="g-white">
          <stop offset="0" stopColor="#fff" stopOpacity=".9" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="g-water" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#CFE3EE" />
          <stop offset="1" stopColor="#8DB7D3" />
        </linearGradient>
        <linearGradient id="g-mist" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0" />
          <stop offset="1" stopColor="#fff" stopOpacity=".6" />
        </linearGradient>
      </defs>
    </svg>
  );
}

/* ───────────── basic wrappers ───────────── */
export function Svg({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <svg viewBox="0 0 400 800" preserveAspectRatio="xMidYMid slice" className={`absolute inset-0 h-full w-full ${className}`} aria-hidden="true">
      {children}
    </svg>
  );
}

export function Hill({ pts, fill, edge, bottom = 820 }: { pts: Pt[]; fill: string; edge?: string; bottom?: number }) {
  return <path d={hillPath(pts, bottom)} fill={fill} stroke={edge} strokeWidth={edge ? 1.6 : 0} />;
}

/* ───────────── sky things ───────────── */
export function Cloud({ x, y, s = 1, fill = "#fff", op = 0.9, dur = 46 }: { x: number; y: number; s?: number; fill?: string; op?: number; dur?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={op}>
      <g className="drift" style={sty({ animationDuration: `${dur}s`, animationDelay: `${-(x % 13)}s` })}>
        <rect x="0" y="22" width="132" height="26" rx="13" fill={fill} />
        <circle cx="38" cy="24" r="21" fill={fill} />
        <circle cx="72" cy="15" r="27" fill={fill} />
        <circle cx="102" cy="27" r="19" fill={fill} />
        <rect x="8" y="38" width="118" height="10" rx="5" fill="#B9A9C4" opacity=".16" />
      </g>
    </g>
  );
}

export function Sun({ x, y, r = 34, color = "#FFE9B8", rays = true }: { x: number; y: number; r?: number; color?: string; rays?: boolean }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      <circle r={r * 5} fill="url(#g-sun)" className="glow-breathe" />
      {rays && (
        <g className="spin">
          {Array.from({ length: 12 }, (_, i) => (
            <path key={i} d={`M0,0L${-r * 0.5},${-r * 5.2}L${r * 0.5},${-r * 5.2}Z`} fill="#FFF3D0" opacity=".16" transform={`rotate(${i * 30})`} />
          ))}
        </g>
      )}
      <circle r={r * 1.25} fill="#FFF3D0" opacity=".55" />
      <circle r={r} fill={color} />
    </g>
  );
}

export function Bird({ x, y, s = 1, delay = 0 }: { x: number; y: number; s?: number; delay?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <g className="bird" style={sty({ animationDelay: `${delay}s` })}>
        <path d="M0,0 q7,-8 14,0 q7,-8 14,0" fill="none" stroke="#6C5C69" strokeWidth="1.8" strokeLinecap="round" />
      </g>
    </g>
  );
}

/* ───────────── flowers ───────────── */
export function FlowerHead({ r = 10, c1 = P.blush, c2 = P.rose, center = P.gold, n = 6, off = 0, fat = 0.5 }: { r?: number; c1?: string; c2?: string; center?: string; n?: number; off?: number; fat?: number }) {
  return (
    <g>
      <path d={petalsPath(n, r, r * fat, off)} fill={c1} />
      <path d={petalsPath(n, r * 0.66, r * fat * 0.7, off + 180 / n)} fill={c2} />
      <circle r={r * 0.2} fill={center} />
    </g>
  );
}

type FlowerProps = {
  x: number;
  y: number;
  s?: number;
  h?: number;
  c1?: string;
  c2?: string;
  center?: string;
  n?: number;
  r?: number;
  d?: number;
  lean?: number;
  stem?: string;
  leaves?: boolean;
};

export function Flower({ x, y, s = 1, h = 44, c1 = P.blush, c2 = P.rose, center = P.gold, n = 6, r = 11, d = 0, lean = 0, stem = P.sageDeep, leaves = true }: FlowerProps) {
  const sw = -((Math.abs(x * 7 + y * 3) % 50) / 10);
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <g className="sway" style={sty({ animationDelay: `${sw}s` })}>
        <g className="grow" style={sty({ animationDelay: `${d}s` })}>
          <path d={`M0,0C${lean * 0.2},${-h * 0.35} ${lean},${-h * 0.7} ${lean},${-h}`} stroke={stem} strokeWidth="2.4" fill="none" strokeLinecap="round" />
          {leaves && (
            <>
              <path d={`M0,${-h * 0.3}q-12,-2 -15,-12q11,0 15,12z`} fill={stem} />
              <path d={`M${lean * 0.4},${-h * 0.5}q12,-2 15,-12q-11,0 -15,12z`} fill={P.sageMid} />
            </>
          )}
        </g>
        <g transform={`translate(${lean} ${-h})`}>
          <g className="bloom" style={sty({ animationDelay: `${d + 0.55}s` })}>
            <FlowerHead r={r} c1={c1} c2={c2} center={center} n={n} />
          </g>
        </g>
      </g>
    </g>
  );
}

export const FLOWER_SETS: { c1: string; c2: string; center: string; n: number }[] = [
  { c1: P.blush, c2: P.rose, center: P.gold, n: 6 },
  { c1: P.lav, c2: P.ivory, center: P.goldDeep, n: 5 },
  { c1: P.peach, c2: P.blush, center: P.roseDeep, n: 6 },
  { c1: P.ivory, c2: P.cream, center: P.gold, n: 8 },
  { c1: P.rose, c2: P.blush, center: P.ivory, n: 5 },
  { c1: P.lavDeep, c2: P.lav, center: P.ivory, n: 6 },
];

export function Meadow({ list, delay = 0, spread = 3 }: { list: [number, number, number][]; delay?: number; spread?: number }) {
  return (
    <>
      {list.map(([x, y, s], i) => {
        const f = FLOWER_SETS[i % FLOWER_SETS.length];
        return <Flower key={i} x={x} y={y} s={s} h={38 + (i % 3) * 8} lean={((i % 5) - 2) * 3} d={delay + (i / list.length) * spread} {...f} />;
      })}
    </>
  );
}

export function Grass({ x, y, s = 1, color = P.sageDark, n = 9, h = 56, seed = 5 }: { x: number; y: number; s?: number; color?: string; n?: number; h?: number; seed?: number }) {
  const r = rng(seed);
  let d = "";
  for (let i = 0; i < n; i++) {
    const bx = (i - n / 2) * 7 + r() * 4;
    const bh = h * (0.55 + r() * 0.6);
    const lean = (r() - 0.5) * 26;
    d += `M${bx},0Q${bx + lean * 0.4},${-bh * 0.6} ${bx + lean},${-bh}Q${bx + lean * 0.5 + 5},${-bh * 0.5} ${bx + 9},0Z`;
  }
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <g className="sway">
        <path d={d} fill={color} />
      </g>
    </g>
  );
}

/* ───────────── butterflies ───────────── */
export function Butterfly({ x, y, s = 1, c1 = P.blush, c2 = P.rose, v = 1 }: { x: number; y: number; s?: number; c1?: string; c2?: string; v?: 1 | 2 | 3 }) {
  const wing = (
    <g>
      <path d="M0,0C-6,-14 -22,-18 -24,-8C-26,2 -12,6 0,2Z" fill={c1} />
      <path d="M0,3C-8,6 -16,16 -10,18C-4,20 0,10 0,3Z" fill={c2} />
      <circle cx="-14" cy="-5" r="2.2" fill="#fff" opacity=".6" />
    </g>
  );
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <g className={`flutter f${v}`}>
        <g className="bf-tilt">
          <g className="wing">{wing}</g>
          <g transform="scale(-1 1)">
            <g className="wing">{wing}</g>
          </g>
          <ellipse rx="1.4" ry="6.5" cy="2" fill="#5B4646" />
          <path d="M0,-4q-3,-6 -6,-7M0,-4q3,-6 6,-7" stroke="#5B4646" strokeWidth=".8" fill="none" />
        </g>
      </g>
    </g>
  );
}

/* ───────────── lanterns, fireflies ───────────── */
export function Lantern({ x, y, s = 1, delay = 0, color = "#F6B876", hang = 0, str = "#8A7360" }: { x: number; y: number; s?: number; delay?: number; color?: string; hang?: number; str?: string }) {
  const v = sty({ "--ld": `${delay}s` });
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      {hang > 0 && <line x1="0" y1={-hang} x2="0" y2="0" stroke={str} strokeWidth="1.2" />}
      <circle cx="0" cy="20" r="56" fill="url(#g-lantern)" className="lit-glow" style={v} />
      <g className="swing" style={sty({ animationDelay: `${-(Math.abs(x) % 7) * 0.45}s` })}>
        <rect x="-5" y="-1" width="10" height="4" rx="1.5" fill={P.goldDeep} />
        <ellipse cx="0" cy="19" rx="13" ry="16" fill="#D8C7AA" />
        <ellipse cx="0" cy="19" rx="13" ry="16" fill={color} className="lit" style={v} />
        <ellipse cx="0" cy="19" rx="5.5" ry="16" fill="none" stroke="rgba(150,80,40,.3)" strokeWidth=".9" />
        <path d="M-12.5,12H12.5M-12.5,26H12.5" stroke="rgba(150,80,40,.22)" strokeWidth=".8" />
        <rect x="-6" y="34" width="12" height="3.5" rx="1.5" fill={P.goldDeep} />
        <path d="M0,37v8" stroke={P.gold} strokeWidth="1.2" />
        <circle cy="47" r="1.8" fill={P.gold} />
      </g>
    </g>
  );
}

export function Fireflies({ n = 16, seed = 3, area = [20, 220, 380, 520] }: { n?: number; seed?: number; area?: [number, number, number, number] }) {
  const r = rng(seed);
  const count = LITE ? Math.ceil(n / 2) : n;
  return (
    <>
      {Array.from({ length: count }, (_, i) => {
        const x = area[0] + r() * (area[2] - area[0]);
        const y = area[1] + r() * (area[3] - area[1]);
        return (
          <g key={i} transform={`translate(${x.toFixed(0)} ${y.toFixed(0)})`}>
            <g className="ff" style={sty({ "--dx": `${((r() - 0.5) * 70).toFixed(0)}px`, "--dy": `${((r() - 0.5) * 60).toFixed(0)}px`, "--t": `${(6 + r() * 5).toFixed(1)}s`, "--fd": `${(-r() * 8).toFixed(1)}s` })}>
              <circle r="9" fill="url(#g-fly)" className="ff-glow" />
              <circle r="1.7" fill="#FFF6C8" />
            </g>
          </g>
        );
      })}
    </>
  );
}

/* ───────────── trees ───────────── */
export function Tree({ x, y, s = 1, delay = 0, cols = [P.rose, P.blush, P.lav], trunk = "#A18570", seed = 7, rx = 150, ry = 108, cy = -235, many = 34 }: { x: number; y: number; s?: number; delay?: number; cols?: string[]; trunk?: string; seed?: number; rx?: number; ry?: number; cy?: number; many?: number }) {
  const r = rng(seed);
  const total = LITE ? Math.ceil(many * 0.65) : many;
  const clumps = Array.from({ length: total }, (_, i) => {
    const layer = i < total * 0.4 ? 0 : i < total * 0.75 ? 1 : 2;
    const a = r() * Math.PI * 2;
    const dd = Math.sqrt(r()) * (layer === 2 ? 0.7 : 0.9);
    return { x: Math.cos(a) * dd * rx * 0.85, y: cy + Math.sin(a) * dd * ry * 0.82, r: (layer === 0 ? 30 : layer === 1 ? 24 : 17) + r() * 12, c: cols[layer], i };
  });
  const dots = Array.from({ length: LITE ? 14 : 30 }, () => ({ x: (r() - 0.5) * rx * 1.7, y: cy + (r() - 0.5) * ry * 1.6, r: 1.8 + r() * 2.2 }));
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <ellipse cx="0" cy="4" rx="70" ry="9" fill="#4B3A3E" opacity=".13" />
      <g className="grow" style={sty({ animationDelay: `${delay}s`, animationDuration: "1.6s" })}>
        <path d="M-16,2C-13,-60 -11,-100 -7,-150L-5,-225L6,-225L9,-150C12,-100 14,-60 18,2Z" fill={trunk} />
        <path d="M2,2C4,-60 4,-100 6,-150L6,-225L9,-150C12,-100 14,-60 18,2Z" fill="#000" opacity=".1" />
        <path d="M0,-130C-30,-150 -62,-170 -88,-205M0,-150C30,-170 56,-190 82,-218M-2,-175C-10,-200 -20,-218 -34,-245" stroke={trunk} strokeWidth="7" strokeLinecap="round" fill="none" />
      </g>
      {clumps.map((c) => (
        <circle key={c.i} cx={c.x} cy={c.y} r={c.r} fill={c.c} className="bloom" style={sty({ animationDelay: `${delay + 1 + c.i * 0.075}s` })} />
      ))}
      {dots.map((d, i) => (
        <circle key={i} cx={d.x} cy={d.y} r={d.r} fill={P.ivory} opacity=".85" className="bloom" style={sty({ animationDelay: `${delay + 2.2 + i * 0.05}s` })} />
      ))}
    </g>
  );
}

export function RoundTree({ x, y, s = 1, fill = P.sageMid, fill2 = P.sage, trunk = "#9A8068" }: { x: number; y: number; s?: number; fill?: string; fill2?: string; trunk?: string }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x="-3" y="-30" width="6" height="30" rx="2" fill={trunk} />
      <circle cx="0" cy="-46" r="22" fill={fill} />
      <circle cx="-9" cy="-52" r="12" fill={fill2} opacity=".8" />
      <circle cx="10" cy="-40" r="10" fill={fill2} opacity=".55" />
    </g>
  );
}

export function PineTree({ x, y, s = 1, fill = P.sageDeep, fill2 = P.sageMid }: { x: number; y: number; s?: number; fill?: string; fill2?: string }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x="-2.5" y="-14" width="5" height="14" fill="#8F7560" />
      <path d="M0,-92L22,-44L-22,-44Z" fill={fill} />
      <path d="M0,-72L28,-22L-28,-22Z" fill={fill2} />
      <path d="M0,-48L34,-8L-34,-8Z" fill={fill} />
    </g>
  );
}

/* ───────────── water + path ───────────── */
export function Stream({ pts, lines = 6, delay = 0, fill = "url(#g-water)", line = "#fff" }: { pts: Rp[]; lines?: number; delay?: number; fill?: string; line?: string }) {
  const fs = Array.from({ length: lines }, (_, i) => -0.38 + (i * 0.76) / (lines - 1 || 1));
  return (
    <g className="fade-in" style={sty({ animationDelay: `${delay}s` })}>
      <path d={ribbonPath(pts)} fill={fill} />
      {fs.map((f, i) => (
        <path key={i} d={ribbonLine(pts, f)} fill="none" stroke={line} strokeOpacity=".6" strokeWidth="1.6" strokeLinecap="round" strokeDasharray="9 30" className="flow" style={sty({ animationDelay: `${-i * 1.7}s`, animationDuration: `${4.5 + (i % 3)}s` })} />
      ))}
    </g>
  );
}

export function Walkway({ pts, fill = "#F3E7CC", edge = "#E2CFA4", glow = true, delay = 0, glowColor = "#FFE7A8" }: { pts: Rp[]; fill?: string; edge?: string; glow?: boolean; delay?: number; glowColor?: string }) {
  const d = ribbonPath(pts);
  return (
    <g className="fade-in" style={sty({ animationDelay: `${delay}s` })}>
      <path d={d} fill={fill} stroke={edge} strokeWidth="2" strokeLinejoin="round" />
      <path d={ribbonLine(pts, 0)} fill="none" stroke={edge} strokeOpacity=".7" strokeWidth="1.3" strokeDasharray="2 12" strokeLinecap="round" />
      {glow && <path d={d} fill={glowColor} className="path-glow" style={sty({ animationDelay: `${delay + 1.6}s` })} />}
    </g>
  );
}

/* ───────────── bridge ───────────── */
export const archY = (u: number, h: number) => -h * 4 * u * (1 - u);

export function Bridge({ x, y, w = 220, h = 44, delay = 0, thick = 13, posts = 7, rail = "#F4EAD4" }: { x: number; y: number; w?: number; h?: number; delay?: number; thick?: number; posts?: number; rail?: string }) {
  const N = 12;
  const cols = [P.wood, "#BDA07A"];
  const segs = Array.from({ length: N }, (_, i) => {
    const u0 = i / N;
    const u1 = (i + 1) / N;
    const xa = -w / 2 + u0 * w;
    const xb = -w / 2 + u1 * w;
    const ya = archY(u0, h);
    const yb = archY(u1, h);
    return { pts: `${xa},${ya} ${xb},${yb} ${xb},${yb + thick} ${xa},${ya + thick}`, c: cols[i % 2], i };
  });
  const ps = Array.from({ length: posts }, (_, k) => {
    const u = 0.07 + (k * 0.86) / (posts - 1);
    const px = -w / 2 + u * w;
    const base = archY(u, h) + 1;
    return { px, base, top: base - 21 };
  });
  return (
    <g transform={`translate(${x} ${y})`}>
      <ellipse cx="0" cy={thick + 10} rx={w * 0.46} ry="7" fill="#35506A" opacity=".16" />
      {[-1, 1].map((sd) => (
        <rect key={sd} x={sd * (w / 2) - 9} y="-2" width="18" height={thick + 16} rx="3" fill="#CFC3B0" />
      ))}
      {segs.map((s) => (
        <polygon key={s.i} points={s.pts} fill={s.c} className="popup" style={sty({ animationDelay: `${delay + s.i * 0.07}s` })} />
      ))}
      <g className="rise" style={sty({ animationDelay: `${delay + 1}s` })}>
        <path d={smoothLine(ps.map((p) => [p.px, p.top] as Pt))} stroke={rail} strokeWidth="2.6" fill="none" strokeLinecap="round" />
        <path d={smoothLine(ps.map((p) => [p.px, p.base - 9] as Pt))} stroke={rail} strokeWidth="1.4" fill="none" opacity=".85" />
        {ps.map((p, i) => (
          <g key={i}>
            <rect x={p.px - 1.6} y={p.top} width="3.2" height="21" rx="1.6" fill={rail} />
            <circle cx={p.px} cy={p.top - 1} r="2.8" fill={P.gold} />
          </g>
        ))}
      </g>
    </g>
  );
}

export function LilyPad({ x, y, s = 1, bloom = true, d = 0 }: { x: number; y: number; s?: number; bloom?: boolean; d?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <ellipse rx="22" ry="7" fill={P.sageMid} />
      <ellipse rx="22" ry="7" cy="-1" fill={P.sage} opacity=".8" />
      {bloom && (
        <g transform="translate(2 -4)" className="bloom" style={sty({ animationDelay: `${d}s` })}>
          <FlowerHead r={9} c1={P.blush} c2={P.rose} center={P.gold} n={7} />
        </g>
      )}
    </g>
  );
}

/* ───────────── wedding arch ───────────── */
export function Arch({ x, y, s = 1, delay = 0 }: { x: number; y: number; s?: number; delay?: number }) {
  const r = rng(21);
  const cols = [
    [P.blush, P.rose],
    [P.ivory, P.cream],
    [P.rose, P.blush],
    [P.lav, P.ivory],
    [P.peach, P.blush],
  ];
  const blooms: { x: number; y: number; r: number; c: string[]; i: number }[] = [];
  const K = LITE ? 16 : 24;
  for (let k = 0; k <= K; k++) {
    const th = Math.PI - (k * Math.PI) / K;
    blooms.push({ x: Math.cos(th) * 56 + (r() - 0.5) * 4, y: -118 - Math.sin(th) * 58 + (r() - 0.5) * 4, r: 6.5 + r() * 3, c: cols[k % 5], i: blooms.length });
  }
  for (const sd of [-1, 1]) {
    for (let k = 0; k < (LITE ? 4 : 7); k++) {
      blooms.push({ x: sd * (56 + (r() - 0.5) * 10), y: -112 + k * (LITE ? 24 : 16) + (r() - 0.5) * 6, r: 6 + r() * 4 + (k > 4 ? 2 : 0), c: cols[(k + (sd > 0 ? 2 : 0)) % 5], i: blooms.length });
    }
  }
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <circle cx="0" cy="-80" r="150" fill="url(#g-sun)" className="glow-breathe" style={sty({ animationDelay: `${delay}s` })} />
      <ellipse cx="0" cy="-64" rx="50" ry="60" fill="#FFF3D2" opacity=".78" className="fade-in" style={sty({ animationDelay: `${delay}s` })} />
      <g className="rise" style={sty({ animationDelay: `${delay}s` })}>
        <ellipse cx="0" cy="3" rx="74" ry="7" fill="#4B3A3E" opacity=".14" />
        {[-1, 1].map((sd) => (
          <g key={sd}>
            <rect x={sd * 56 - 5} y="-122" width="10" height="124" rx="2" fill={P.ivory} stroke="#E4D3B0" strokeWidth="1" />
            <rect x={sd * 56 - 8} y="-8" width="16" height="10" rx="2" fill={P.gold} />
          </g>
        ))}
        <path d="M-56,-118Q-56,-178 0,-178Q56,-178 56,-118" fill="none" stroke={P.ivory} strokeWidth="10" strokeLinecap="round" />
        <path d="M-56,-118Q-56,-178 0,-178Q56,-178 56,-118" fill="none" stroke={P.gold} strokeWidth="2" strokeLinecap="round" />
        <path d="M-52,-110C-40,-70 -46,-30 -40,0M52,-110C40,-70 46,-30 40,0" fill="none" stroke="#fff" strokeWidth="8" opacity=".35" className="sway" />
      </g>
      {blooms.map((b) => (
        <g key={b.i} transform={`translate(${b.x.toFixed(1)} ${b.y.toFixed(1)})`}>
          <ellipse cx="-6" cy="3" rx="6" ry="3" fill={P.sageDeep} transform={`rotate(${b.i * 40})`} />
          <g className="bloom" style={sty({ animationDelay: `${delay + 0.8 + b.i * 0.05}s` })}>
            <FlowerHead r={b.r} c1={b.c[0]} c2={b.c[1]} center={P.gold} n={5} fat={0.6} />
          </g>
        </g>
      ))}
      {[[-40, -150], [34, -160], [-62, -70], [58, -60], [0, -190]].map(([sx, sy], i) => (
        <g key={i} transform={`translate(${sx} ${sy})`}>
          <path d="M0,-5L1.4,-1.4L5,0L1.4,1.4L0,5L-1.4,1.4L-5,0L-1.4,-1.4Z" fill="#FFF6D6" className="twinkle" style={sty({ animationDelay: `${delay + 1 + i * 0.5}s` })} />
        </g>
      ))}
    </g>
  );
}

/* ───────────── lanterns on strings and poles ───────────── */
export function Garland({ x1, y1, x2, y2, sag = 40, items = 6, delay = 0, s = 1, color = "#F6B876", str = "#8A7360" }: { x1: number; y1: number; x2: number; y2: number; sag?: number; items?: number; delay?: number; s?: number; color?: string; str?: string }) {
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2 + sag * 2;
  const pt = (t: number): Pt => [(1 - t) * (1 - t) * x1 + 2 * (1 - t) * t * mx + t * t * x2, (1 - t) * (1 - t) * y1 + 2 * (1 - t) * t * my + t * t * y2];
  return (
    <g>
      <path d={`M${x1},${y1}Q${mx},${my} ${x2},${y2}`} fill="none" stroke={str} strokeWidth="1.4" />
      {Array.from({ length: items }, (_, i) => {
        const [lx, ly] = pt((i + 0.5) / items);
        return <Lantern key={i} x={lx} y={ly + 6} s={s * (0.9 + (i % 2) * 0.15)} hang={6} delay={delay + i * 0.5} color={color} str={str} />;
      })}
    </g>
  );
}

export function Pole({ x, y, h = 300, w = 6, fill = "#8E7A70" }: { x: number; y: number; h?: number; w?: number; fill?: string }) {
  return (
    <g>
      <rect x={x - w / 2} y={y} width={w} height={h} rx={w / 2} fill={fill} />
      <circle cx={x} cy={y} r={w * 0.8} fill={P.goldDeep} />
    </g>
  );
}

export function Sparkles({ list }: { list: [number, number, number][] }) {
  return (
    <>
      {list.map(([x, y, s], i) => (
        <g key={i} transform={`translate(${x} ${y}) scale(${s})`}>
          <path d="M0,-6L1.6,-1.6L6,0L1.6,1.6L0,6L-1.6,1.6L-6,0L-1.6,-1.6Z" fill="#FFF6D6" className="twinkle" style={sty({ animationDelay: `${-i * 0.7}s` })} />
        </g>
      ))}
    </>
  );
}
